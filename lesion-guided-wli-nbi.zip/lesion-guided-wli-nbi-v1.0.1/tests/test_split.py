import pandas as pd

from split_dataset import patient_table, random_split


def test_random_split_has_no_patient_overlap():
    frame = pd.DataFrame(
        {
            "sample_id": [f"s{i}" for i in range(40)],
            "patient_id": [f"p{i}" for i in range(40)],
            "year": [2023] * 40,
            "label": ["GPL", "EGC"] * 20,
            "wli_path": ["wli.jpg"] * 40,
            "nbi_path": ["nbi.jpg"] * 40,
            "manual_mask_path": ["mask.png"] * 40,
        }
    )
    patients = patient_table(frame)
    train, val, test = random_split(patients, 0.7, 0.15, 3047)
    train_ids = set(train.patient_id)
    val_ids = set(val.patient_id)
    test_ids = set(test.patient_id)
    assert not train_ids & val_ids
    assert not train_ids & test_ids
    assert not val_ids & test_ids
