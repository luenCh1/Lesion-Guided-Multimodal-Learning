import torch

from models import LesionGuidedDualModel, PSACARAFEResUNet


def test_segmentation_shape():
    model = PSACARAFEResUNet().eval()
    with torch.no_grad():
        output = model(torch.randn(1, 3, 64, 64))
    assert output.shape == (1, 1, 64, 64)


def test_classifier_shape():
    model = LesionGuidedDualModel(pretrained=False).eval()
    with torch.no_grad():
        output = model(
            torch.rand(1, 3, 64, 64),
            torch.rand(1, 3, 64, 64),
            torch.rand(1, 1, 64, 64),
        )
    assert output.shape == (1, 2)
