# Citation

Please cite the associated manuscript when using this code in academic work.
Until the manuscript citation is available, cite the public software release
using the repository URL, release tag, title, and version:

> Lesion-guided multimodal learning from white-light and narrow-band endoscopy,
> software version 1.0.0, 2026.

After the manuscript is accepted, replace this provisional software citation
with the final article citation and archive a tagged release (for example,
`v1.0.0`) so that the exact code version remains identifiable.
