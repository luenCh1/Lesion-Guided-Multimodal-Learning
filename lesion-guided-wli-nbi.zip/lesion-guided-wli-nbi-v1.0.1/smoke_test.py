"""Fast architecture check without clinical data."""
import torch

from models import LesionGuidedDualModel, PSACARAFEResUNet


def main():
    torch.set_num_threads(2)
    with torch.no_grad():
        segmentation = PSACARAFEResUNet().eval()
        seg_output = segmentation(torch.randn(1, 3, 64, 64))
        assert seg_output.shape == (1, 1, 64, 64)

        classifier = LesionGuidedDualModel(pretrained=False).eval()
        cls_output = classifier(
            torch.rand(1, 3, 64, 64),
            torch.rand(1, 3, 64, 64),
            torch.rand(1, 1, 64, 64),
        )
        assert cls_output.shape == (1, 2)
    print("Smoke test passed.")


if __name__ == "__main__":
    main()
