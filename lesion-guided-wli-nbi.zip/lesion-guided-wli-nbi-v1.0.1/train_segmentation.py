"""Train PSA-CARAFE-ResUNet using train.csv and val.csv only."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from data_pipeline import SegmentationDataset
from losses import DiceBCELoss
from models import PSACARAFEResUNet
from reproducibility import save_json, seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-csv", required=True)
    parser.add_argument("--val-csv", required=True)
    parser.add_argument("--data-root", default=".")
    parser.add_argument("--output-dir", default="outputs/segmentation")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--image-size", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-5)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=3047)
    parser.add_argument("--no-psa", action="store_true", help="Ablation: disable PSA")
    parser.add_argument("--no-carafe", action="store_true", help="Ablation: disable CARAFE")
    return parser.parse_args()


def batch_dice(logits: torch.Tensor, target: torch.Tensor, threshold: float = 0.5) -> torch.Tensor:
    prediction = (torch.sigmoid(logits) >= threshold).float()
    dims = tuple(range(1, prediction.ndim))
    intersection = torch.sum(prediction * target, dim=dims)
    denominator = torch.sum(prediction, dim=dims) + torch.sum(target, dim=dims)
    return ((2.0 * intersection + 1e-7) / (denominator + 1e-7)).mean()


def run_epoch(model, loader, criterion, device, optimizer=None):
    training = optimizer is not None
    model.train(training)
    total_loss = 0.0
    total_dice = 0.0
    total_samples = 0
    progress = tqdm(loader, leave=False)
    for batch in progress:
        images = batch["image"].to(device, non_blocking=True)
        masks = batch["mask"].to(device, non_blocking=True)
        if training:
            optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(training):
            logits = model(images)
            loss = criterion(logits, masks)
            if training:
                loss.backward()
                optimizer.step()
        size = images.size(0)
        total_loss += float(loss.item()) * size
        total_dice += float(batch_dice(logits.detach(), masks).item()) * size
        total_samples += size
        progress.set_postfix(loss=f"{total_loss / total_samples:.4f}", dice=f"{total_dice / total_samples:.4f}")
    return total_loss / total_samples, total_dice / total_samples


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    save_json(vars(args), output_dir / "config.json")

    image_size = (args.image_size, args.image_size)
    train_set = SegmentationDataset(args.train_csv, args.data_root, size=image_size, training=True)
    val_set = SegmentationDataset(args.val_csv, args.data_root, size=image_size, training=False)
    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.workers, pin_memory=True)
    val_loader = DataLoader(val_set, batch_size=args.batch_size, shuffle=False, num_workers=args.workers, pin_memory=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = PSACARAFEResUNet(use_psa=not args.no_psa, use_carafe=not args.no_carafe).to(device)
    criterion = DiceBCELoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", patience=15, factor=0.5)

    history_path = output_dir / "history.csv"
    with history_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["epoch", "learning_rate", "train_loss", "train_dice", "val_loss", "val_dice"])
        writer.writeheader()

    best_dice = -1.0
    for epoch in range(1, args.epochs + 1):
        train_loss, train_dice = run_epoch(model, train_loader, criterion, device, optimizer)
        with torch.no_grad():
            val_loss, val_dice = run_epoch(model, val_loader, criterion, device)
        scheduler.step(val_dice)
        row = {
            "epoch": epoch,
            "learning_rate": optimizer.param_groups[0]["lr"],
            "train_loss": train_loss,
            "train_dice": train_dice,
            "val_loss": val_loss,
            "val_dice": val_dice,
        }
        with history_path.open("a", newline="", encoding="utf-8") as handle:
            csv.DictWriter(handle, fieldnames=row.keys()).writerow(row)
        checkpoint = {
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "epoch": epoch,
            "val_dice": val_dice,
            "use_psa": not args.no_psa,
            "use_carafe": not args.no_carafe,
            "image_size": [args.image_size, args.image_size],
        }
        torch.save(checkpoint, output_dir / "last.pt")
        if val_dice > best_dice:
            best_dice = val_dice
            torch.save(checkpoint, output_dir / "best.pt")
        print(
            f"Epoch {epoch:03d}: train_loss={train_loss:.4f}, train_dice={train_dice:.4f}, "
            f"val_loss={val_loss:.4f}, val_dice={val_dice:.4f}, best={best_dice:.4f}"
        )


if __name__ == "__main__":
    main()
