"""Reproduce manuscript AUC confidence intervals and DeLong comparisons.

Example:
    python manuscript_statistics.py \
      --model "Lesion-guided WLI only=outputs/wli_only/patient_predictions.csv" \
      --model "NBI only=outputs/nbi_only/patient_predictions.csv" \
      --model "Unguided WLI+NBI=outputs/dual_raw/patient_predictions.csv" \
      --model "Predicted-mask model=outputs/final_predicted/patient_predictions.csv" \
      --model "Labeled-mask reference=outputs/final_manual/patient_predictions.csv" \
      --output-dir outputs/manuscript_statistics

Every CSV must contain patient_id, label, and egc_probability and must represent
the same held-out patients. AUC 95% CIs use the Hanley-McNeil asymptotic method.
Pairwise correlated AUCs are compared with the two-sided DeLong test.
"""
from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import pandas as pd

from metrics import delong_auc_test, hanley_mcneil_auc_ci


def parse_model_argument(value: str):
    if "=" not in value:
        raise argparse.ArgumentTypeError("--model must be supplied as NAME=PATH")
    name, path = value.split("=", 1)
    name = name.strip()
    path = path.strip()
    if not name or not path:
        raise argparse.ArgumentTypeError("--model must be supplied as NAME=PATH")
    return name, path


def load_predictions(name: str, path: str) -> pd.DataFrame:
    frame = pd.read_csv(path, dtype={"patient_id": str})
    required = {"patient_id", "label", "egc_probability"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"{name}: missing columns {sorted(missing)}")
    frame = frame[["patient_id", "label", "egc_probability"]].copy()
    frame["label"] = frame["label"].astype(str).str.upper().replace({"GPL": "0", "EGC": "1", "GC": "1"}).astype(int)
    if frame["patient_id"].duplicated().any():
        raise ValueError(f"{name}: patient_predictions.csv must contain one row per patient")
    return frame.sort_values("patient_id").reset_index(drop=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", action="append", type=parse_model_argument, required=True, help="Repeat NAME=PATH for each model")
    parser.add_argument("--output-dir", default="outputs/manuscript_statistics")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    models = {}
    reference_ids = None
    reference_labels = None
    for name, path in args.model:
        frame = load_predictions(name, path)
        if reference_ids is None:
            reference_ids = frame.patient_id.tolist()
            reference_labels = frame.label.to_numpy()
        else:
            if frame.patient_id.tolist() != reference_ids:
                raise ValueError(f"{name}: patient IDs/order do not match the first model")
            if not (frame.label.to_numpy() == reference_labels).all():
                raise ValueError(f"{name}: labels do not match the first model")
        models[name] = frame

    auc_rows = []
    for name, frame in models.items():
        ci = hanley_mcneil_auc_ci(frame.label.to_numpy(), frame.egc_probability.to_numpy())
        auc_rows.append({"model": name, **ci})
    pd.DataFrame(auc_rows).to_csv(output_dir / "auc_hanley_mcneil.csv", index=False, encoding="utf-8-sig")

    pair_rows = []
    for name_a, name_b in itertools.combinations(models.keys(), 2):
        a = models[name_a]
        b = models[name_b]
        result = delong_auc_test(reference_labels, a.egc_probability.to_numpy(), b.egc_probability.to_numpy())
        pair_rows.append({"model_a": name_a, "model_b": name_b, **result})
    pd.DataFrame(pair_rows).to_csv(output_dir / "delong_pairwise.csv", index=False, encoding="utf-8-sig")

    print(pd.DataFrame(auc_rows).to_string(index=False))
    if pair_rows:
        print("\nPairwise DeLong comparisons:")
        print(pd.DataFrame(pair_rows).to_string(index=False))


if __name__ == "__main__":
    main()
