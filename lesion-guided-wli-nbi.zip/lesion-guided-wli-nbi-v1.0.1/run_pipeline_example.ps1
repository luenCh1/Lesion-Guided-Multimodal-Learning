$ErrorActionPreference = "Stop"

$DataRoot = "data/our"
$SplitDir = "$DataRoot/splits"

python split_dataset.py --metadata "$DataRoot/metadata.csv" --output-dir $SplitDir --mode temporal --val-year 2024 --test-year 2025
python audit_dataset.py --data-root $DataRoot --csv "$SplitDir/train.csv" "$SplitDir/val.csv" "$SplitDir/test.csv" --check-images

python train_segmentation.py --train-csv "$SplitDir/train.csv" --val-csv "$SplitDir/val.csv" --data-root $DataRoot --output-dir outputs/segmentation_full
python evaluate_segmentation.py --test-csv "$SplitDir/val.csv" --checkpoint outputs/segmentation_full/best.pt --data-root $DataRoot --output-dir outputs/segmentation_val
python evaluate_segmentation.py --test-csv "$SplitDir/test.csv" --checkpoint outputs/segmentation_full/best.pt --data-root $DataRoot --output-dir outputs/segmentation_test

python train_classifier.py --train-csv "$SplitDir/train.csv" --val-csv outputs/segmentation_val/test_with_predicted_masks.csv --data-root $DataRoot --output-dir outputs/classifier_full
python evaluate_classifier.py --test-csv outputs/segmentation_test/test_with_predicted_masks.csv --checkpoint outputs/classifier_full/best.pt --data-root $DataRoot --output-dir outputs/classifier_test
