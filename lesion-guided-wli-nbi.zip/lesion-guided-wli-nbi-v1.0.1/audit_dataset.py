"""Audit metadata, paths, labels, and patient leakage before training."""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from PIL import Image

from data_pipeline import load_metadata, resolve_path


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", default=".")
    parser.add_argument("--csv", nargs="+", required=True, help="One or more split CSV files")
    parser.add_argument("--check-images", action="store_true")
    return parser.parse_args()


def main():
    args = parse_args()
    frames = {}
    for csv_path in args.csv:
        name = Path(csv_path).stem
        frame = load_metadata(csv_path)
        frames[name] = frame
        print(f"{name}: {len(frame)} samples, {frame.patient_id.nunique()} patients")
        print(frame.groupby("label").agg(samples=("sample_id", "count"), patients=("patient_id", "nunique")))
        if args.check_images:
            for _, row in frame.iterrows():
                for column in ["wli_path", "nbi_path", "manual_mask_path"]:
                    path = resolve_path(row[column], args.data_root)
                    if not path.exists():
                        raise FileNotFoundError(f"Missing {column}: {path}")
                    with Image.open(path) as image:
                        image.verify()
    names = list(frames)
    for i, left in enumerate(names):
        for right in names[i + 1 :]:
            overlap = set(frames[left].patient_id) & set(frames[right].patient_id)
            if overlap:
                raise ValueError(f"Patient leakage between {left} and {right}: {sorted(overlap)[:20]}")
    print("Audit passed: no patient overlap detected.")


if __name__ == "__main__":
    main()
