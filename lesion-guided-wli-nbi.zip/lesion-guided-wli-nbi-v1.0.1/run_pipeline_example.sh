#!/usr/bin/env bash
set -euo pipefail

DATA_ROOT="data/our"
SPLIT_DIR="$DATA_ROOT/splits"

python split_dataset.py --metadata "$DATA_ROOT/metadata.csv" --output-dir "$SPLIT_DIR" --mode temporal --val-year 2024 --test-year 2025
python audit_dataset.py --data-root "$DATA_ROOT" --csv "$SPLIT_DIR/train.csv" "$SPLIT_DIR/val.csv" "$SPLIT_DIR/test.csv" --check-images

python train_segmentation.py --train-csv "$SPLIT_DIR/train.csv" --val-csv "$SPLIT_DIR/val.csv" --data-root "$DATA_ROOT" --output-dir outputs/segmentation_full
python evaluate_segmentation.py --test-csv "$SPLIT_DIR/val.csv" --checkpoint outputs/segmentation_full/best.pt --data-root "$DATA_ROOT" --output-dir outputs/segmentation_val
python evaluate_segmentation.py --test-csv "$SPLIT_DIR/test.csv" --checkpoint outputs/segmentation_full/best.pt --data-root "$DATA_ROOT" --output-dir outputs/segmentation_test

python train_classifier.py --train-csv "$SPLIT_DIR/train.csv" --val-csv outputs/segmentation_val/test_with_predicted_masks.csv --data-root "$DATA_ROOT" --output-dir outputs/classifier_full
python evaluate_classifier.py --test-csv outputs/segmentation_test/test_with_predicted_masks.csv --checkpoint outputs/classifier_full/best.pt --data-root "$DATA_ROOT" --output-dir outputs/classifier_test
