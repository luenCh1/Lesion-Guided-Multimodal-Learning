"""Datasets and image preprocessing for the CMPB experiments."""
from __future__ import annotations

import random
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from PIL import Image, ImageOps
from torch.utils.data import Dataset


REQUIRED_COLUMNS = {"sample_id", "patient_id", "label", "wli_path", "nbi_path", "manual_mask_path"}
LABEL_TO_INDEX = {"GPL": 0, "EGC": 1, "GC": 1}


def load_metadata(csv_path: str | Path) -> pd.DataFrame:
    frame = pd.read_csv(csv_path, dtype={"sample_id": str, "patient_id": str})
    missing = REQUIRED_COLUMNS.difference(frame.columns)
    if missing:
        raise ValueError(f"Metadata is missing required columns: {sorted(missing)}")
    frame = frame.copy()
    frame["label"] = frame["label"].astype(str).str.upper().replace({"GC": "EGC"})
    invalid = sorted(set(frame["label"]) - {"GPL", "EGC"})
    if invalid:
        raise ValueError(f"Unsupported labels: {invalid}. Use GPL or EGC.")
    if frame["sample_id"].duplicated().any():
        duplicates = frame.loc[frame["sample_id"].duplicated(), "sample_id"].tolist()[:10]
        raise ValueError(f"Duplicate sample_id values found: {duplicates}")
    return frame


def resolve_path(value: str, data_root: str | Path) -> Path:
    path = Path(str(value))
    return path if path.is_absolute() else Path(data_root) / path


def pil_to_tensor(image: Image.Image) -> torch.Tensor:
    array = np.asarray(image, dtype=np.float32)
    if array.ndim == 2:
        array = array[..., None]
    array = np.ascontiguousarray(array.transpose(2, 0, 1)) / 255.0
    return torch.from_numpy(array)


def normalize_rgb(tensor: torch.Tensor) -> torch.Tensor:
    mean = torch.tensor([0.485, 0.456, 0.406], dtype=tensor.dtype).view(3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225], dtype=tensor.dtype).view(3, 1, 1)
    return (tensor - mean) / std


class SpatialTransform:
    """Synchronized spatial transform for an RGB image and binary mask."""

    def __init__(
        self,
        size: Tuple[int, int] = (256, 256),
        training: bool = False,
        rotation: float = 15.0,
        horizontal_flip: float = 0.5,
        vertical_flip: float = 0.0,
    ):
        self.size = size
        self.training = training
        self.rotation = rotation
        self.horizontal_flip = horizontal_flip
        self.vertical_flip = vertical_flip

    def sample_parameters(self) -> Dict[str, float | bool]:
        return {
            "angle": random.uniform(-self.rotation, self.rotation) if self.training else 0.0,
            "hflip": self.training and random.random() < self.horizontal_flip,
            "vflip": self.training and random.random() < self.vertical_flip,
        }

    def apply_image(self, image: Image.Image, params: Dict[str, float | bool]) -> Image.Image:
        image = image.resize((self.size[1], self.size[0]), resample=Image.Resampling.BILINEAR)
        if params["hflip"]:
            image = ImageOps.mirror(image)
        if params["vflip"]:
            image = ImageOps.flip(image)
        if params["angle"]:
            image = image.rotate(float(params["angle"]), resample=Image.Resampling.BILINEAR, fillcolor=(0, 0, 0))
        return image

    def apply_mask(self, mask: Image.Image, params: Dict[str, float | bool]) -> Image.Image:
        mask = mask.resize((self.size[1], self.size[0]), resample=Image.Resampling.NEAREST)
        if params["hflip"]:
            mask = ImageOps.mirror(mask)
        if params["vflip"]:
            mask = ImageOps.flip(mask)
        if params["angle"]:
            mask = mask.rotate(float(params["angle"]), resample=Image.Resampling.NEAREST, fillcolor=0)
        return mask


class SegmentationDataset(Dataset):
    def __init__(
        self,
        metadata_csv: str | Path,
        data_root: str | Path = ".",
        size: Tuple[int, int] = (256, 256),
        training: bool = False,
    ):
        self.frame = load_metadata(metadata_csv)
        self.data_root = Path(data_root)
        self.transform = SpatialTransform(size=size, training=training, rotation=35, horizontal_flip=0.3, vertical_flip=0.3)

    def __len__(self) -> int:
        return len(self.frame)

    def __getitem__(self, index: int):
        row = self.frame.iloc[index]
        image_path = resolve_path(row["wli_path"], self.data_root)
        mask_path = resolve_path(row["manual_mask_path"], self.data_root)
        with Image.open(image_path) as handle:
            image = handle.convert("RGB")
        with Image.open(mask_path) as handle:
            mask = handle.convert("L")

        params = self.transform.sample_parameters()
        image = self.transform.apply_image(image, params)
        mask = self.transform.apply_mask(mask, params)

        image_tensor = normalize_rgb(pil_to_tensor(image))
        mask_tensor = (pil_to_tensor(mask) > 0.5).float()
        return {
            "image": image_tensor,
            "mask": mask_tensor,
            "sample_id": str(row["sample_id"]),
            "patient_id": str(row["patient_id"]),
        }


class MultimodalDataset(Dataset):
    """WLI + NBI classification dataset.

    WLI and its mask share the same augmentation. NBI receives an independent
    augmentation because the modalities are not assumed to be pixel registered.
    """

    def __init__(
        self,
        metadata_csv: str | Path,
        data_root: str | Path = ".",
        size: Tuple[int, int] = (256, 256),
        training: bool = False,
        mask_source: str = "manual",
    ):
        self.frame = load_metadata(metadata_csv)
        self.data_root = Path(data_root)
        self.mask_source = mask_source
        if mask_source not in {"manual", "predicted"}:
            raise ValueError("mask_source must be 'manual' or 'predicted'")
        if mask_source == "predicted" and "predicted_mask_path" not in self.frame.columns:
            raise ValueError("predicted_mask_path column is required for predicted masks")
        self.wli_transform = SpatialTransform(size=size, training=training, rotation=15, horizontal_flip=0.5)
        self.nbi_transform = SpatialTransform(size=size, training=training, rotation=15, horizontal_flip=0.5)

    def __len__(self) -> int:
        return len(self.frame)

    def __getitem__(self, index: int):
        row = self.frame.iloc[index]
        mask_column = "manual_mask_path" if self.mask_source == "manual" else "predicted_mask_path"
        mask_value = row.get(mask_column, "")
        if pd.isna(mask_value) or str(mask_value).strip() == "":
            raise FileNotFoundError(f"No {mask_column} for sample {row['sample_id']}")

        with Image.open(resolve_path(row["wli_path"], self.data_root)) as handle:
            wli = handle.convert("RGB")
        with Image.open(resolve_path(row["nbi_path"], self.data_root)) as handle:
            nbi = handle.convert("RGB")
        with Image.open(resolve_path(str(mask_value), self.data_root)) as handle:
            mask = handle.convert("L")

        wli_params = self.wli_transform.sample_parameters()
        nbi_params = self.nbi_transform.sample_parameters()
        wli = self.wli_transform.apply_image(wli, wli_params)
        mask = self.wli_transform.apply_mask(mask, wli_params)
        nbi = self.nbi_transform.apply_image(nbi, nbi_params)

        return {
            "nbi": pil_to_tensor(nbi),
            "wli": pil_to_tensor(wli),
            "mask": (pil_to_tensor(mask) > 0.5).float(),
            "label": torch.tensor(LABEL_TO_INDEX[str(row["label"]).upper()], dtype=torch.long),
            "sample_id": str(row["sample_id"]),
            "patient_id": str(row["patient_id"]),
        }
