# Third-party notices

## RepVGG

`models/repvgg.py` contains code adapted from the official RepVGG implementation:

- Project: **RepVGG: Making VGG-style ConvNets Great Again**
- Original repository: `DingXiaoH/RepVGG`
- Original copyright: Copyright (c) 2020 DingXiaoH
- License: MIT License

The original copyright and license terms are retained in `licenses/RepVGG-LICENSE`. The repository-level MIT
license applies to the original code in this project; third-party components
remain subject to their respective notices and licenses.

No third-party pretrained weights are redistributed in this repository.
