"""Single-case EGC probability prediction."""
from __future__ import annotations

import argparse

import torch
from PIL import Image

from data_pipeline import SpatialTransform, pil_to_tensor
from models import LesionGuidedDualModel


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wli", required=True)
    parser.add_argument("--nbi", required=True)
    parser.add_argument("--mask", required=True)
    parser.add_argument("--checkpoint", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    image_size = tuple(checkpoint.get("image_size", [256, 256]))
    transform = SpatialTransform(size=image_size, training=False)
    with Image.open(args.wli) as handle:
        wli = transform.apply_image(handle.convert("RGB"), transform.sample_parameters())
    with Image.open(args.nbi) as handle:
        nbi = transform.apply_image(handle.convert("RGB"), transform.sample_parameters())
    with Image.open(args.mask) as handle:
        mask = transform.apply_mask(handle.convert("L"), transform.sample_parameters())

    model = LesionGuidedDualModel(
        use_cga=bool(checkpoint.get("use_cga", True)),
        pretrained=False,
        modality_mode=checkpoint.get("modality_mode", "dual"),
        wli_input_mode=checkpoint.get("wli_input_mode", "full"),
    )
    model.load_state_dict(checkpoint["model_state"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device).eval()
    with torch.no_grad():
        logits = model(
            pil_to_tensor(nbi).unsqueeze(0).to(device),
            pil_to_tensor(wli).unsqueeze(0).to(device),
            (pil_to_tensor(mask) > 0.5).float().unsqueeze(0).to(device),
        )
        probability = torch.softmax(logits, dim=1)[0, 1].item()
    threshold = float(checkpoint.get("threshold", 0.5))
    label = "EGC" if probability >= threshold else "GPL"
    print(f"EGC probability: {probability:.6f}")
    print(f"Threshold: {threshold:.6f}")
    print(f"Prediction: {label}")


if __name__ == "__main__":
    main()
