"""Analyze a paired endoscopist reader study against the AI model.

Recommended reader CSV (long format):
patient_id,label,reader_id,reader_level,prediction,confidence,reading_time_seconds

- label/prediction may be GPL/EGC or 0/1.
- confidence is an integer from 1 (lowest) to 5 (highest).
- Reader ROC AUC is computed from the manuscript signed ordinal score:
  GPL predictions -> -confidence; EGC predictions -> +confidence.
- Exact McNemar tests compare paired binary correctness of AI versus each reader.

If the confidence column is absent, the script remains backward compatible and
uses binary prediction (0/1) as the reader ROC score, but prints a warning.
"""
from __future__ import annotations

import argparse
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest
from sklearn.metrics import roc_auc_score

from metrics import binary_classification_metrics, hanley_mcneil_auc_ci


def parse_label(value):
    text = str(value).strip().upper()
    if text in {"EGC", "GC", "1", "1.0"}:
        return 1
    if text in {"GPL", "0", "0.0"}:
        return 0
    raise ValueError(f"Unknown label: {value}")


def mcnemar_exact(ai_correct: np.ndarray, reader_correct: np.ndarray):
    ai_only = int(np.sum(ai_correct & ~reader_correct))
    reader_only = int(np.sum(~ai_correct & reader_correct))
    discordant = ai_only + reader_only
    p_value = 1.0 if discordant == 0 else float(
        binomtest(min(ai_only, reader_only), discordant, 0.5, alternative="two-sided").pvalue
    )
    return ai_only, reader_only, p_value


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reader-csv", required=True)
    parser.add_argument("--ai-predictions", required=True)
    parser.add_argument("--output-dir", default="outputs/reader_study")
    return parser.parse_args()


def main():
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    readers = pd.read_csv(args.reader_csv, dtype={"patient_id": str, "reader_id": str})
    required = {"patient_id", "label", "reader_id", "reader_level", "prediction", "reading_time_seconds"}
    missing = required.difference(readers.columns)
    if missing:
        raise ValueError(f"Reader CSV missing columns: {sorted(missing)}")

    has_confidence = "confidence" in readers.columns
    if not has_confidence:
        warnings.warn(
            "Reader CSV has no confidence column. Reader AUC will use binary predictions rather than the manuscript "
            "signed ordinal confidence score. Add confidence=1..5 to reproduce the manuscript reader AUC.",
            RuntimeWarning,
        )

    readers["label"] = readers["label"].map(parse_label)
    readers["prediction"] = readers["prediction"].map(parse_label)
    if has_confidence:
        readers["confidence"] = pd.to_numeric(readers["confidence"], errors="raise").astype(int)
        if not readers["confidence"].between(1, 5).all():
            raise ValueError("confidence must be an integer from 1 to 5")

    ai = pd.read_csv(args.ai_predictions, dtype={"patient_id": str})
    if "predicted_label" not in ai.columns:
        raise ValueError("AI predictions must contain predicted_label")
    if "label" not in ai.columns:
        raise ValueError("AI predictions must contain label")
    if "egc_probability" not in ai.columns:
        raise ValueError("AI predictions must contain egc_probability")
    ai["label"] = ai["label"].map(parse_label)
    ai["predicted_label"] = ai["predicted_label"].map(parse_label)

    rows = []
    for reader_id, group in readers.groupby("reader_id"):
        merged = group.merge(
            ai[["patient_id", "label", "predicted_label", "egc_probability"]],
            on="patient_id",
            suffixes=("_reader", "_ai"),
        )
        if len(merged) != len(ai):
            raise ValueError(f"Reader {reader_id} did not assess all AI test patients: {len(merged)} vs {len(ai)}")
        if not np.array_equal(merged.label_reader.to_numpy(), merged.label_ai.to_numpy()):
            raise ValueError(f"Label mismatch for reader {reader_id}")

        labels = merged.label_reader.to_numpy()
        predictions = merged.prediction.to_numpy()
        reader_binary_metrics = binary_classification_metrics(labels, predictions.astype(float), threshold=0.5)

        if has_confidence:
            signed_score = np.where(predictions == 1, merged.confidence.to_numpy(), -merged.confidence.to_numpy()).astype(float)
        else:
            signed_score = predictions.astype(float)

        reader_auc = float(roc_auc_score(labels, signed_score))
        reader_auc_ci = hanley_mcneil_auc_ci(labels, signed_score)

        ai_correct = merged.predicted_label.to_numpy() == labels
        reader_correct = predictions == labels
        ai_only, reader_only, p_value = mcnemar_exact(ai_correct, reader_correct)

        rows.append(
            {
                "reader_id": reader_id,
                "reader_level": str(group.reader_level.iloc[0]),
                "reader_auc": reader_auc,
                "reader_auc_ci_lower_95": reader_auc_ci["lower_95"],
                "reader_auc_ci_upper_95": reader_auc_ci["upper_95"],
                "reader_accuracy": reader_binary_metrics["accuracy"],
                "reader_sensitivity": reader_binary_metrics["sensitivity"],
                "reader_specificity": reader_binary_metrics["specificity"],
                "reader_precision": reader_binary_metrics["precision"],
                "reader_npv": reader_binary_metrics["npv"],
                "reader_f1": reader_binary_metrics["f1"],
                "mean_reading_time_seconds": float(group.reading_time_seconds.mean()),
                "median_reading_time_seconds": float(group.reading_time_seconds.median()),
                "ai_correct_reader_wrong": ai_only,
                "ai_wrong_reader_correct": reader_only,
                "mcnemar_exact_p": p_value,
            }
        )

    reader_results = pd.DataFrame(rows)
    reader_results.to_csv(output_dir / "reader_level_results.csv", index=False, encoding="utf-8-sig")

    numeric = [
        column for column in reader_results.columns
        if column not in {"reader_id", "reader_level"}
        and pd.api.types.is_numeric_dtype(reader_results[column])
    ]
    level_summary = reader_results.groupby("reader_level", as_index=False)[numeric].mean()
    level_summary.to_csv(output_dir / "experience_level_summary.csv", index=False, encoding="utf-8-sig")

    ai_threshold = float(ai["threshold"].iloc[0]) if "threshold" in ai.columns else 0.5
    ai_metrics = binary_classification_metrics(ai.label.to_numpy(), ai.egc_probability.to_numpy(), threshold=ai_threshold)
    ai_auc_ci = hanley_mcneil_auc_ci(ai.label.to_numpy(), ai.egc_probability.to_numpy())
    ai_row = {**ai_metrics, "auc_ci_lower_95": ai_auc_ci["lower_95"], "auc_ci_upper_95": ai_auc_ci["upper_95"]}
    pd.DataFrame([ai_row]).to_csv(output_dir / "ai_metrics.csv", index=False, encoding="utf-8-sig")

    print(reader_results.to_string(index=False))


if __name__ == "__main__":
    main()
