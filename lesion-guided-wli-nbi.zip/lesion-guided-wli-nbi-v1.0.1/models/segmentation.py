"""Corrected PSA-CARAFE-ResUNet segmentation model."""
from __future__ import annotations

import torch
import torch.nn as nn

from .attention import CARAFE, ParallelPolarizedSelfAttention


class ResidualBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )
        else:
            self.shortcut = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = self.shortcut(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return self.relu(out + identity)


class DoubleConv(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int):
        super().__init__(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )


class PSACARAFEResUNet(nn.Module):
    """ResUNet with PSA in encoder stages and CARAFE in decoder.

    The original code defined PSA modules but never called them and used wrong
    channel counts for stages 2 and 3. Both problems are fixed here.
    """

    def __init__(self, in_channels: int = 3, out_channels: int = 1, use_psa: bool = True, use_carafe: bool = True):
        super().__init__()
        self.use_psa = use_psa
        self.use_carafe = use_carafe
        self.pool = nn.MaxPool2d(2)

        self.enc1 = ResidualBlock(in_channels, 64)
        self.enc2 = ResidualBlock(64, 128)
        self.enc3 = ResidualBlock(128, 256)
        self.enc4 = ResidualBlock(256, 512)

        self.psa1 = ParallelPolarizedSelfAttention(64) if use_psa else nn.Identity()
        self.psa2 = ParallelPolarizedSelfAttention(128) if use_psa else nn.Identity()
        self.psa3 = ParallelPolarizedSelfAttention(256) if use_psa else nn.Identity()

        self.bridge = DoubleConv(512, 512)

        if use_carafe:
            self.up4 = CARAFE(512, 512)
            self.up3 = CARAFE(512, 256)
            self.up2 = CARAFE(256, 128)
            self.up1 = CARAFE(128, 64)
        else:
            self.up4 = nn.ConvTranspose2d(512, 512, 4, 2, 1)
            self.up3 = nn.ConvTranspose2d(512, 256, 4, 2, 1)
            self.up2 = nn.ConvTranspose2d(256, 128, 4, 2, 1)
            self.up1 = nn.ConvTranspose2d(128, 64, 4, 2, 1)

        self.dec4 = ResidualBlock(1024, 512)
        self.dec3 = ResidualBlock(512, 256)
        self.dec2 = ResidualBlock(256, 128)
        self.dec1 = ResidualBlock(128, 64)
        self.head = nn.Conv2d(64, out_channels, kernel_size=1)

        self._initialize_weights()

    def _initialize_weights(self) -> None:
        for module in self.modules():
            if isinstance(module, nn.Conv2d):
                nn.init.kaiming_normal_(module.weight, mode="fan_out", nonlinearity="relu")
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.BatchNorm2d):
                nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e1 = self.psa1(self.enc1(x))
        e2 = self.psa2(self.enc2(self.pool(e1)))
        e3 = self.psa3(self.enc3(self.pool(e2)))
        e4 = self.enc4(self.pool(e3))

        x = self.bridge(self.pool(e4))
        x = self.dec4(torch.cat([self.up4(x), e4], dim=1))
        x = self.dec3(torch.cat([self.up3(x), e3], dim=1))
        x = self.dec2(torch.cat([self.up2(x), e2], dim=1))
        x = self.dec1(torch.cat([self.up1(x), e1], dim=1))
        return self.head(x)  # logits; no sigmoid during training
