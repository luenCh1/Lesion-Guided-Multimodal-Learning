"""Lesion-guided WLI-NBI classification model with corrected CGA."""
from __future__ import annotations

import warnings
from pathlib import Path

import torch
import torch.nn as nn

from .attention import CGAFusion
from .repvgg import create_RepVGG_A0


IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def _safe_repvgg_a0(pretrained: bool) -> nn.Module:
    """Load local RepVGG weights when available, otherwise use random initialization."""
    if not pretrained:
        return create_RepVGG_A0(pretrained=False)
    weight_path = Path(__file__).resolve().parent / "pretrained" / "RepVGG-A0-train.pth"
    if not weight_path.exists():
        warnings.warn(
            f"Pretrained RepVGG weights were requested but not found at {weight_path}. "
            "Training will start from random initialization.",
            RuntimeWarning,
        )
        return create_RepVGG_A0(pretrained=False)
    return create_RepVGG_A0(pretrained=True)


def _expand_conv_weight(weight: torch.Tensor, in_channels: int) -> torch.Tensor:
    """Expand RGB weights to 7 channels while controlling activation magnitude.

    Channels are [WLI RGB, mask, masked-WLI RGB]. RGB and masked-RGB receive
    half of the original weight; the mask channel receives the RGB mean.
    """
    out_channels, old_channels, kh, kw = weight.shape
    if old_channels != 3 or in_channels != 7:
        raise ValueError("This initializer expects a 3-to-7 channel expansion")
    expanded = weight.new_zeros((out_channels, in_channels, kh, kw))
    expanded[:, 0:3] = 0.5 * weight
    expanded[:, 4:7] = 0.5 * weight
    expanded[:, 3:4] = weight.mean(dim=1, keepdim=True) * 0.25
    return expanded


class RepVGGFeatureBackbone(nn.Module):
    def __init__(self, in_channels: int = 3, pretrained: bool = False):
        super().__init__()
        self.model = _safe_repvgg_a0(pretrained)
        self.out_channels = 192
        if in_channels != 3:
            self._replace_input_convolutions(in_channels)

    def _replace_input_convolutions(self, in_channels: int) -> None:
        block = self.model.stage0
        for branch_name in ("rbr_dense", "rbr_1x1"):
            branch = getattr(block, branch_name)
            old_conv = branch.conv
            new_conv = nn.Conv2d(
                in_channels,
                old_conv.out_channels,
                kernel_size=old_conv.kernel_size,
                stride=old_conv.stride,
                padding=old_conv.padding,
                dilation=old_conv.dilation,
                groups=old_conv.groups,
                bias=False,
            )
            with torch.no_grad():
                if old_conv.in_channels == 3 and in_channels == 7:
                    new_conv.weight.copy_(_expand_conv_weight(old_conv.weight, in_channels))
                else:
                    nn.init.kaiming_normal_(new_conv.weight, mode="fan_out", nonlinearity="relu")
            branch.conv = new_conv

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.model.stage0(x)
        x = self.model.stage1(x)
        x = self.model.stage2(x)
        return self.model.stage3(x)


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, in_channels: int, planes: int, stride: int = 1):
        super().__init__()
        out_channels = planes * self.expansion
        self.conv1 = nn.Conv2d(in_channels, planes, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, 3, stride=stride, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, out_channels, 1, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        if stride != 1 or in_channels != out_channels:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )
        else:
            self.downsample = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = self.downsample(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        return self.relu(out + identity)


class LesionGuidedDualModel(nn.Module):
    """Dual-stream WLI-NBI classifier.

    Positive class is EGC (label 1); GPL is label 0.
    """

    def __init__(
        self,
        num_classes: int = 2,
        use_cga: bool = True,
        pretrained: bool = False,
        modality_mode: str = "dual",
        wli_input_mode: str = "full",
    ):
        super().__init__()
        if modality_mode not in {"dual", "nbi_only", "wli_only"}:
            raise ValueError("modality_mode must be dual, nbi_only, or wli_only")
        if wli_input_mode not in {"full", "raw", "raw_mask", "raw_masked"}:
            raise ValueError("wli_input_mode must be full, raw, raw_mask, or raw_masked")
        self.use_cga = use_cga
        self.modality_mode = modality_mode
        self.wli_input_mode = wli_input_mode
        self.nbi_backbone = RepVGGFeatureBackbone(3, pretrained=pretrained)
        self.wli_backbone = RepVGGFeatureBackbone(7, pretrained=pretrained)
        channels = self.nbi_backbone.out_channels
        self.align = nn.Conv2d(self.wli_backbone.out_channels, channels, kernel_size=1)
        self.fusion = (
            CGAFusion(channels)
            if use_cga
            else nn.Sequential(
                nn.Conv2d(channels * 2, channels, 1, bias=False),
                nn.BatchNorm2d(channels),
                nn.ReLU(inplace=True),
                nn.Conv2d(channels, channels, 3, padding=1, bias=False),
                nn.BatchNorm2d(channels),
                nn.ReLU(inplace=True),
            )
        )
        self.refine = nn.Sequential(
            Bottleneck(channels, channels, stride=2),
            Bottleneck(channels * 4, channels * 2, stride=2),
        )
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Linear(channels * 2 * Bottleneck.expansion, num_classes)
        self.register_buffer("mean", torch.tensor(IMAGENET_MEAN).view(1, 3, 1, 1), persistent=False)
        self.register_buffer("std", torch.tensor(IMAGENET_STD).view(1, 3, 1, 1), persistent=False)

    def _normalize(self, image: torch.Tensor) -> torch.Tensor:
        return (image - self.mean) / self.std

    def forward(self, nbi: torch.Tensor, wli: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        if mask.ndim != 4 or mask.shape[1] != 1:
            raise ValueError(f"mask must have shape [B,1,H,W], got {mask.shape}")
        mask = mask.clamp(0.0, 1.0)
        masked_wli = wli * mask
        zero_mask = torch.zeros_like(mask)
        normalized_wli = self._normalize(wli)
        normalized_masked_wli = self._normalize(masked_wli)
        zero_rgb_features = torch.zeros_like(normalized_wli)
        if self.wli_input_mode == "full":
            mask_component, masked_component = mask, normalized_masked_wli
        elif self.wli_input_mode == "raw":
            mask_component, masked_component = zero_mask, zero_rgb_features
        elif self.wli_input_mode == "raw_mask":
            mask_component, masked_component = mask, zero_rgb_features
        else:  # raw_masked
            mask_component, masked_component = zero_mask, normalized_masked_wli

        nbi_input = self._normalize(nbi)
        wli_input = torch.cat([normalized_wli, mask_component, masked_component], dim=1)
        nbi_features = self.nbi_backbone(nbi_input)
        wli_features = self.align(self.wli_backbone(wli_input))
        if self.modality_mode == "nbi_only":
            fused = nbi_features
        elif self.modality_mode == "wli_only":
            fused = wli_features
        elif self.use_cga:
            fused = self.fusion(nbi_features, wli_features)
        else:
            fused = self.fusion(torch.cat([nbi_features, wli_features], dim=1))
        fused = self.refine(fused)
        return self.classifier(torch.flatten(self.pool(fused), 1))
