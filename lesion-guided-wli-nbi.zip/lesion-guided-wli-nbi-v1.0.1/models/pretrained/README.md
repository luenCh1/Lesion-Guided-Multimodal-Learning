# Optional pretrained weights

No pretrained weights are distributed with this repository.

To initialize the RepVGG-A0 backbone from compatible pretrained weights, place
the file below in this directory:

```text
RepVGG-A0-train.pth
```

Then add `--pretrained` when running `train_classifier.py`.

Users are responsible for obtaining weights from an authorized source and for
complying with the corresponding license. If weights are not present, the code
falls back to random initialization and emits a warning.
