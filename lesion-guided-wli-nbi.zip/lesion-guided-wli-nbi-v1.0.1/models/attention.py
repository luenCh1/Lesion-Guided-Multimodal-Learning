"""Attention and content-aware upsampling modules.

The implementation keeps the original study design but fixes the PSA channel
configuration and the duplicate sigmoid in cross-modal fusion.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class CARAFE(nn.Module):
    """Content-Aware ReAssembly of FEatures upsampling."""

    def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 3, scale_factor: int = 2):
        super().__init__()
        if in_channels < 4:
            raise ValueError("CARAFE requires in_channels >= 4")
        self.kernel_size = kernel_size
        self.scale_factor = scale_factor
        compressed = max(1, in_channels // 4)
        self.down = nn.Conv2d(in_channels, compressed, kernel_size=1)
        self.encoder = nn.Conv2d(
            compressed,
            scale_factor**2 * kernel_size**2,
            kernel_size=kernel_size,
            stride=1,
            padding=kernel_size // 2,
        )
        self.out = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        n, c, h, w = x.shape
        kernels = self.encoder(self.down(x))
        kernels = F.pixel_shuffle(kernels, self.scale_factor)
        kernels = F.softmax(kernels, dim=1)
        kernels = kernels.unfold(2, self.scale_factor, self.scale_factor)
        kernels = kernels.unfold(3, self.scale_factor, self.scale_factor)
        kernels = kernels.reshape(n, self.kernel_size**2, h, w, self.scale_factor**2)
        kernels = kernels.permute(0, 2, 3, 1, 4)

        padded = F.pad(
            x,
            (self.kernel_size // 2,) * 4,
            mode="constant",
            value=0,
        )
        patches = padded.unfold(2, self.kernel_size, 1).unfold(3, self.kernel_size, 1)
        patches = patches.reshape(n, c, h, w, self.kernel_size**2)
        patches = patches.permute(0, 2, 3, 1, 4)

        out = torch.matmul(patches, kernels)
        out = out.reshape(n, h, w, c * self.scale_factor**2).permute(0, 3, 1, 2)
        out = F.pixel_shuffle(out, self.scale_factor)
        return self.out(out)


class ParallelPolarizedSelfAttention(nn.Module):
    """Parallel polarized self-attention (channel + spatial branches)."""

    def __init__(self, channels: int):
        super().__init__()
        hidden = max(1, channels // 2)
        self.channels = channels
        self.ch_wv = nn.Conv2d(channels, hidden, kernel_size=1)
        self.ch_wq = nn.Conv2d(channels, 1, kernel_size=1)
        self.ch_wz = nn.Conv2d(hidden, channels, kernel_size=1)
        self.layer_norm = nn.LayerNorm(channels)

        self.sp_wv = nn.Conv2d(channels, hidden, kernel_size=1)
        self.sp_wq = nn.Conv2d(channels, hidden, kernel_size=1)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape

        channel_value = self.ch_wv(x).reshape(b, -1, h * w)
        channel_query = self.ch_wq(x).reshape(b, h * w, 1)
        channel_query = F.softmax(channel_query, dim=1)
        channel_context = torch.matmul(channel_value, channel_query).unsqueeze(-1)
        channel_weight = self.ch_wz(channel_context).reshape(b, c)
        channel_weight = torch.sigmoid(self.layer_norm(channel_weight)).reshape(b, c, 1, 1)
        channel_out = channel_weight * x

        spatial_value = self.sp_wv(x).reshape(b, -1, h * w)
        spatial_query = self.avg_pool(self.sp_wq(x)).reshape(b, 1, -1)
        spatial_query = F.softmax(spatial_query, dim=-1)
        spatial_weight = torch.matmul(spatial_query, spatial_value).reshape(b, 1, h, w)
        spatial_out = torch.sigmoid(spatial_weight) * x
        return channel_out + spatial_out


class SpatialAttention(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=7, padding=3, padding_mode="reflect")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        avg = torch.mean(x, dim=1, keepdim=True)
        maximum = torch.amax(x, dim=1, keepdim=True)
        return self.conv(torch.cat([avg, maximum], dim=1))


class ChannelAttention(nn.Module):
    def __init__(self, channels: int, reduction: int = 8):
        super().__init__()
        hidden = max(1, channels // reduction)
        self.net = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, hidden, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, kernel_size=1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class PixelAttention(nn.Module):
    """Return attention logits; sigmoid is applied exactly once in CGAFusion."""

    def __init__(self, channels: int):
        super().__init__()
        self.conv = nn.Conv2d(
            2 * channels,
            channels,
            kernel_size=7,
            padding=3,
            padding_mode="reflect",
            groups=channels,
        )

    def forward(self, x: torch.Tensor, prior: torch.Tensor) -> torch.Tensor:
        stacked = torch.stack([x, prior], dim=2)
        b, c, two, h, w = stacked.shape
        return self.conv(stacked.reshape(b, c * two, h, w))


class CGAFusion(nn.Module):
    """Cross-modal channel/spatial/pixel attention fusion with one sigmoid."""

    def __init__(self, channels: int, reduction: int = 8):
        super().__init__()
        self.spatial = SpatialAttention()
        self.channel = ChannelAttention(channels, reduction)
        self.pixel = PixelAttention(channels)
        self.projection = nn.Conv2d(channels, channels, kernel_size=1)

    def forward(self, nbi: torch.Tensor, wli: torch.Tensor) -> torch.Tensor:
        if nbi.shape != wli.shape:
            raise ValueError(f"CGA inputs must have identical shapes, got {nbi.shape} and {wli.shape}")
        initial = nbi + wli
        prior = self.channel(initial) + self.spatial(initial)
        weight = torch.sigmoid(self.pixel(initial, prior))
        fused = initial + weight * nbi + (1.0 - weight) * wli
        return self.projection(fused)
