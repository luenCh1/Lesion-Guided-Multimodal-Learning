"""Leakage-safe patient-level dataset splitting."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

from data_pipeline import load_metadata


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--metadata", required=True)
    parser.add_argument("--output-dir", default="splits")
    parser.add_argument("--mode", choices=["temporal", "random"], default="temporal")
    parser.add_argument("--test-year", type=int, default=2025)
    parser.add_argument("--val-year", type=int, default=2024)
    parser.add_argument("--train-ratio", type=float, default=0.70)
    parser.add_argument("--val-ratio", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=3047)
    return parser.parse_args()


def patient_table(frame: pd.DataFrame) -> pd.DataFrame:
    label_counts = frame.groupby("patient_id")["label"].nunique()
    mixed = label_counts[label_counts > 1]
    if not mixed.empty:
        raise ValueError(
            "A patient has both GPL and EGC labels. Patient-level classification is ambiguous. "
            f"Review these patient IDs: {mixed.index.tolist()[:20]}"
        )
    aggregations = {"label": "first"}
    if "year" in frame.columns:
        aggregations["year"] = "first"
        inconsistent_year = frame.groupby("patient_id")["year"].nunique(dropna=False)
        bad = inconsistent_year[inconsistent_year > 1]
        if not bad.empty:
            raise ValueError(f"Patients with multiple examination years: {bad.index.tolist()[:20]}")
    return frame.groupby("patient_id", as_index=False).agg(aggregations)


def random_split(patients: pd.DataFrame, train_ratio: float, val_ratio: float, seed: int):
    if train_ratio <= 0 or val_ratio <= 0 or train_ratio + val_ratio >= 1:
        raise ValueError("train_ratio and val_ratio must be positive and sum to < 1")
    train_patients, temp = train_test_split(
        patients,
        train_size=train_ratio,
        stratify=patients["label"],
        random_state=seed,
    )
    relative_val = val_ratio / (1.0 - train_ratio)
    val_patients, test_patients = train_test_split(
        temp,
        train_size=relative_val,
        stratify=temp["label"],
        random_state=seed,
    )
    return train_patients, val_patients, test_patients


def temporal_split(patients: pd.DataFrame, test_year: int, val_year: int):
    if "year" not in patients.columns or patients["year"].isna().any():
        raise ValueError("Temporal splitting requires a complete integer year column")
    years = pd.to_numeric(patients["year"], errors="raise").astype(int)
    train = patients[years < val_year]
    val = patients[years == val_year]
    test = patients[years >= test_year]
    excluded = patients[(years > val_year) & (years < test_year)]
    if not excluded.empty:
        raise ValueError(
            f"Years between val_year={val_year} and test_year={test_year} would be unused. "
            "Choose consecutive cutoffs or revise the script."
        )
    if min(len(train), len(val), len(test)) == 0:
        raise ValueError(f"Empty temporal split: train={len(train)}, val={len(val)}, test={len(test)}")
    return train, val, test


def main() -> None:
    args = parse_args()
    frame = load_metadata(args.metadata)
    patients = patient_table(frame)
    if args.mode == "temporal":
        train_p, val_p, test_p = temporal_split(patients, args.test_year, args.val_year)
    else:
        train_p, val_p, test_p = random_split(patients, args.train_ratio, args.val_ratio, args.seed)

    patient_sets = {
        "train": set(train_p.patient_id),
        "val": set(val_p.patient_id),
        "test": set(test_p.patient_id),
    }
    assert not patient_sets["train"] & patient_sets["val"]
    assert not patient_sets["train"] & patient_sets["test"]
    assert not patient_sets["val"] & patient_sets["test"]

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = {}
    for split_name, ids in patient_sets.items():
        subset = frame[frame.patient_id.isin(ids)].copy().sort_values(["patient_id", "sample_id"])
        subset.to_csv(output_dir / f"{split_name}.csv", index=False, encoding="utf-8-sig")
        (output_dir / f"{split_name}.txt").write_text("\n".join(subset.sample_id) + "\n", encoding="utf-8")
        summary[split_name] = {
            "patients": int(subset.patient_id.nunique()),
            "samples": int(len(subset)),
            "GPL_patients": int(subset.loc[subset.label == "GPL", "patient_id"].nunique()),
            "EGC_patients": int(subset.loc[subset.label == "EGC", "patient_id"].nunique()),
        }
    (output_dir / "split_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
