"""Patient-level metrics, confidence intervals, and segmentation measures."""
from __future__ import annotations

from typing import Callable, Dict, Iterable

import numpy as np
import pandas as pd
from scipy.ndimage import binary_erosion, distance_transform_edt
from scipy.stats import norm
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)


def binary_classification_metrics(y_true: np.ndarray, y_score: np.ndarray, threshold: float = 0.5) -> Dict[str, float]:
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    y_pred = (y_score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "auc": float(roc_auc_score(y_true, y_score)) if len(np.unique(y_true)) == 2 else float("nan"),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "sensitivity": float(tp / (tp + fn)) if tp + fn else float("nan"),
        "specificity": float(tn / (tn + fp)) if tn + fp else float("nan"),
        "precision": float(tp / (tp + fp)) if tp + fp else float("nan"),
        "npv": float(tn / (tn + fn)) if tn + fn else float("nan"),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "threshold": float(threshold),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def youden_threshold(y_true: np.ndarray, y_score: np.ndarray) -> float:
    fpr, tpr, thresholds = roc_curve(y_true, y_score)
    finite = np.isfinite(thresholds)
    if not finite.any():
        return 0.5
    index = np.argmax((tpr - fpr)[finite])
    return float(thresholds[finite][index])


def aggregate_patient_predictions(frame: pd.DataFrame, method: str = "mean") -> pd.DataFrame:
    if method not in {"mean", "max"}:
        raise ValueError("Patient aggregation method must be mean or max")
    label_counts = frame.groupby("patient_id")["label"].nunique()
    if (label_counts > 1).any():
        raise ValueError("A patient has inconsistent labels")
    agg_func = "mean" if method == "mean" else "max"
    return (
        frame.groupby("patient_id", as_index=False)
        .agg(label=("label", "first"), egc_probability=("egc_probability", agg_func), n_images=("sample_id", "count"))
    )


def bootstrap_metric_intervals(
    frame: pd.DataFrame,
    threshold: float,
    n_bootstrap: int = 2000,
    seed: int = 3047,
) -> Dict[str, Dict[str, float]]:
    """Patient-level bootstrap confidence intervals.

    The input must contain one row per patient with label and egc_probability.
    """
    rng = np.random.default_rng(seed)
    values = {key: [] for key in ["auc", "accuracy", "sensitivity", "specificity", "precision", "npv", "f1"]}
    n = len(frame)
    for _ in range(n_bootstrap):
        indices = rng.integers(0, n, size=n)
        sample = frame.iloc[indices]
        if sample.label.nunique() < 2:
            continue
        metrics = binary_classification_metrics(sample.label.to_numpy(), sample.egc_probability.to_numpy(), threshold)
        for key in values:
            if np.isfinite(metrics[key]):
                values[key].append(metrics[key])
    output = {}
    for key, samples in values.items():
        if samples:
            output[key] = {
                "lower_95": float(np.percentile(samples, 2.5)),
                "upper_95": float(np.percentile(samples, 97.5)),
            }
        else:
            output[key] = {"lower_95": float("nan"), "upper_95": float("nan")}
    return output


def hanley_mcneil_auc_ci(
    y_true: np.ndarray,
    y_score: np.ndarray,
    alpha: float = 0.05,
) -> Dict[str, float]:
    """Hanley-McNeil asymptotic confidence interval for ROC AUC.

    This matches the method reported in the manuscript. EGC is assumed to be
    the positive class (1) and GPL the negative class (0).
    """
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    if set(np.unique(y_true)) != {0, 1}:
        raise ValueError("Hanley-McNeil AUC CI requires both binary classes 0 and 1")
    auc = float(roc_auc_score(y_true, y_score))
    n_pos = int(np.sum(y_true == 1))
    n_neg = int(np.sum(y_true == 0))
    if n_pos < 2 or n_neg < 2:
        raise ValueError("At least two positive and two negative patients are required")

    q1 = auc / (2.0 - auc)
    q2 = 2.0 * auc * auc / (1.0 + auc)
    variance = (
        auc * (1.0 - auc)
        + (n_pos - 1) * (q1 - auc * auc)
        + (n_neg - 1) * (q2 - auc * auc)
    ) / (n_pos * n_neg)
    se = float(np.sqrt(max(variance, 0.0)))
    z = float(norm.ppf(1.0 - alpha / 2.0))
    return {
        "auc": auc,
        "standard_error": se,
        "lower_95": float(max(0.0, auc - z * se)),
        "upper_95": float(min(1.0, auc + z * se)),
        "n_positive": n_pos,
        "n_negative": n_neg,
    }


def _compute_midrank(values: np.ndarray) -> np.ndarray:
    """Compute 1-based midranks, including ties, for DeLong covariance."""
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind="mergesort")
    sorted_values = values[order]
    n = len(values)
    midranks = np.empty(n, dtype=float)
    i = 0
    while i < n:
        j = i + 1
        while j < n and sorted_values[j] == sorted_values[i]:
            j += 1
        midranks[i:j] = 0.5 * (i + j - 1) + 1.0
        i = j
    output = np.empty(n, dtype=float)
    output[order] = midranks
    return output


def _fast_delong(predictions_sorted_transposed: np.ndarray, label_1_count: int):
    """Fast DeLong covariance for one or more correlated ROC curves."""
    predictions_sorted_transposed = np.asarray(predictions_sorted_transposed, dtype=float)
    m = int(label_1_count)
    n = predictions_sorted_transposed.shape[1] - m
    if m <= 0 or n <= 0:
        raise ValueError("DeLong test requires both positive and negative patients")

    positive = predictions_sorted_transposed[:, :m]
    negative = predictions_sorted_transposed[:, m:]
    k = predictions_sorted_transposed.shape[0]

    tx = np.empty((k, m), dtype=float)
    ty = np.empty((k, n), dtype=float)
    tz = np.empty((k, m + n), dtype=float)
    for row in range(k):
        tx[row] = _compute_midrank(positive[row])
        ty[row] = _compute_midrank(negative[row])
        tz[row] = _compute_midrank(predictions_sorted_transposed[row])

    aucs = tz[:, :m].sum(axis=1) / (m * n) - (m + 1.0) / (2.0 * n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m

    sx = np.atleast_2d(np.cov(v01, bias=False))
    sy = np.atleast_2d(np.cov(v10, bias=False))
    covariance = sx / m + sy / n
    return aucs, covariance


def delong_auc_test(
    y_true: np.ndarray,
    y_score_a: np.ndarray,
    y_score_b: np.ndarray,
) -> Dict[str, float]:
    """Two-sided DeLong test for two correlated ROC AUCs.

    The two score vectors must come from the same patients in the same order.
    """
    y_true = np.asarray(y_true, dtype=int)
    score_a = np.asarray(y_score_a, dtype=float)
    score_b = np.asarray(y_score_b, dtype=float)
    if not (len(y_true) == len(score_a) == len(score_b)):
        raise ValueError("Labels and both score vectors must have the same length")
    if set(np.unique(y_true)) != {0, 1}:
        raise ValueError("DeLong test requires both binary classes 0 and 1")

    # Standard fast-DeLong formulation assumes positive samples appear first.
    order = np.argsort(-y_true, kind="mergesort")
    m = int(np.sum(y_true == 1))
    predictions = np.vstack([score_a, score_b])[:, order]
    aucs, covariance = _fast_delong(predictions, m)

    delta = float(aucs[0] - aucs[1])
    variance = float(covariance[0, 0] + covariance[1, 1] - 2.0 * covariance[0, 1])
    if variance <= 1e-15:
        z_value = 0.0 if abs(delta) <= 1e-15 else float("inf")
        p_value = 1.0 if abs(delta) <= 1e-15 else 0.0
    else:
        z_value = float(delta / np.sqrt(variance))
        p_value = float(2.0 * norm.sf(abs(z_value)))

    return {
        "auc_a": float(aucs[0]),
        "auc_b": float(aucs[1]),
        "delta_auc_a_minus_b": delta,
        "z": z_value,
        "p_value": p_value,
    }


def segmentation_metrics(target: np.ndarray, prediction: np.ndarray) -> Dict[str, float]:
    target = np.asarray(target, dtype=bool)
    prediction = np.asarray(prediction, dtype=bool)
    tp = np.logical_and(target, prediction).sum()
    tn = np.logical_and(~target, ~prediction).sum()
    fp = np.logical_and(~target, prediction).sum()
    fn = np.logical_and(target, ~prediction).sum()
    eps = 1e-8
    dice = (2 * tp + eps) / (2 * tp + fp + fn + eps)
    iou = (tp + eps) / (tp + fp + fn + eps)
    sensitivity = (tp + eps) / (tp + fn + eps)
    specificity = (tn + eps) / (tn + fp + eps)
    precision = (tp + eps) / (tp + fp + eps)
    return {
        "dice": float(dice),
        "iou": float(iou),
        "sensitivity": float(sensitivity),
        "specificity": float(specificity),
        "precision": float(precision),
        "hd95": float(hd95(target, prediction)),
    }


def hd95(target: np.ndarray, prediction: np.ndarray) -> float:
    if not target.any() and not prediction.any():
        return 0.0
    if not target.any() or not prediction.any():
        return float("nan")
    target_surface = np.logical_xor(target, binary_erosion(target))
    pred_surface = np.logical_xor(prediction, binary_erosion(prediction))
    target_distance = distance_transform_edt(~target_surface)
    pred_distance = distance_transform_edt(~pred_surface)
    distances = np.concatenate([target_distance[pred_surface], pred_distance[target_surface]])
    return float(np.percentile(distances, 95)) if distances.size else 0.0
