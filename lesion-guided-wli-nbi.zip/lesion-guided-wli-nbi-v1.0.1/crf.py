"""Optional DenseCRF refinement using the soft foreground probability map.

CRF is not used by default and must be reported only if its ablation is run.
Install optional dependency: pydensecrf.
"""
from __future__ import annotations

import numpy as np


def apply_dense_crf(
    rgb_image: np.ndarray,
    foreground_probability: np.ndarray,
    iterations: int = 10,
    gaussian_sxy: int = 3,
    bilateral_sxy: int = 50,
    bilateral_srgb: int = 10,
) -> np.ndarray:
    try:
        import pydensecrf.densecrf as dcrf
        from pydensecrf.utils import unary_from_softmax
    except ImportError as exc:
        raise ImportError("Install pydensecrf to use optional CRF post-processing") from exc

    image = np.asarray(rgb_image, dtype=np.uint8)
    probability = np.asarray(foreground_probability, dtype=np.float32)
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("rgb_image must have shape [H,W,3]")
    if probability.shape != image.shape[:2]:
        raise ValueError("foreground_probability must match image height and width")
    probability = np.clip(probability, 1e-6, 1.0 - 1e-6)
    probabilities = np.stack([1.0 - probability, probability], axis=0)
    unary = unary_from_softmax(probabilities)

    height, width = probability.shape
    dense = dcrf.DenseCRF2D(width, height, 2)
    dense.setUnaryEnergy(unary)
    dense.addPairwiseGaussian(sxy=gaussian_sxy, compat=3)
    dense.addPairwiseBilateral(sxy=bilateral_sxy, srgb=bilateral_srgb, rgbim=image, compat=10)
    posterior = np.asarray(dense.inference(iterations), dtype=np.float32).reshape(2, height, width)
    return np.argmax(posterior, axis=0).astype(np.uint8)
