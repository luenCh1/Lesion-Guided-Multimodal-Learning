# Code alignment notes — v1.0.1

This maintenance release does not change the neural-network behavior that
produced the manuscript's reported 0.9534 final-model AUC.

Changes are reproducibility/documentation fixes:

1. Makes the manuscript WLI baseline explicit as **lesion-guided WLI only**
   (`--modality-mode wli_only --wli-input-mode full`).
2. Makes the unguided multimodal baseline explicit as
   `--modality-mode dual --wli-input-mode raw`.
3. Saves a human-readable `experiment_label` in classifier configs/checkpoints.
4. Adds Hanley-McNeil AUC confidence intervals and pairwise DeLong testing.
5. Adds `manuscript_statistics.py` to reproduce manuscript ROC statistics from
   frozen patient-level prediction CSV files.
6. Extends reader-study analysis to reproduce the signed five-point confidence
   AUC used in the manuscript while retaining exact McNemar comparisons.
7. Keeps patient-level bootstrap intervals as an optional sensitivity analysis.

No clinical data or trained model outputs are included.
