# Lesion-guided WLI-NBI multimodal learning

Research code for a two-stage framework that combines white-light imaging
(WLI), narrow-band imaging (NBI), lesion segmentation, and cross-guided
attention for differentiating gastric precancerous lesions (GPL) from early
gastric cancer (EGC).

The repository contains **source code only**. It does not contain patient
images, identifiers, clinical records, pathology data, trained checkpoints, or
reader-study results.

> **Research-use disclaimer:** This software is a research prototype and is not
> a medical device. It must not be used for clinical diagnosis or patient care
> without appropriate validation, regulatory review, and institutional approval.

## Framework

1. A PSA-CARAFE-ResUNet segments the lesion on WLI.
2. The WLI branch receives a seven-channel tensor:
   `[WLI RGB, lesion mask, WLI × lesion mask]`.
3. A separate NBI branch extracts NBI features.
4. Cross-guided attention (CGA) fuses the WLI and NBI feature maps without
   explicit pixel-level image registration.
5. The classifier outputs GPL (`0`) or EGC (`1`).

The implementation uses patient-level splitting, selects the segmentation model
by validation Dice, selects the classification model by validation patient-level
AUC, determines the operating threshold on the validation set, and evaluates the
frozen model once on the independent test set.

## Repository contents

| File | Purpose |
|---|---|
| `create_metadata.py` | Build a reviewable metadata table from a legacy folder layout |
| `split_dataset.py` | Patient-level temporal or stratified random splitting |
| `audit_dataset.py` | Detect missing files, duplicate samples, and patient leakage |
| `train_segmentation.py` | Train PSA-CARAFE-ResUNet |
| `evaluate_segmentation.py` | Generate masks and report segmentation metrics with 95% CIs |
| `train_classifier.py` | Train the lesion-guided WLI-NBI classifier |
| `evaluate_classifier.py` | Independent patient-level classification evaluation |
| `analyze_reader_study.py` | Reader accuracy/sensitivity/specificity, signed-confidence AUC, Hanley-McNeil AUC CI, and exact McNemar tests |
| `benchmark_models.py` | Parameters, latency, and optional FLOPs |
| `manuscript_statistics.py` | Hanley-McNeil AUC CIs and pairwise DeLong tests from frozen patient predictions |
| `predict_single.py` | Single-case inference |
| `smoke_test.py` | Architecture test without clinical data |
| `models/` | Segmentation, classification, attention, and RepVGG modules |
| `examples/` | Synthetic CSV templates only |
| `docs/` | Data schema, experiment commands, and reproducibility notes |

## Installation

Python 3.10 or newer is recommended.

```bash
python -m venv .venv
source .venv/bin/activate          # Linux/macOS
# .venv\Scripts\activate           # Windows PowerShell

python -m pip install --upgrade pip
pip install -r requirements.txt
```

Install the PyTorch build appropriate for the local CPU/CUDA environment if the
default pip build is not suitable. Optional dependencies are listed in
`requirements-optional.txt`.

Validate the installation:

```bash
python smoke_test.py
```

Expected output:

```text
Smoke test passed.
```

## Data are not included

Create a private data directory outside the public repository or under the
ignored `data/` path. One metadata row represents one paired WLI-NBI sample:

```text
sample_id,patient_id,year,label,wli_path,nbi_path,manual_mask_path,predicted_mask_path
```

Allowed labels are:

```text
GPL = 0
EGC = 1
```

A synthetic schema example is available in `examples/metadata_template.csv`.
See `docs/DATA_FORMAT.md` before preparing real data.

## Patient-level split

### Recommended temporal split

Example: earlier years for development, 2024 for validation, and 2025 for an
independent temporal test set.

```bash
python split_dataset.py \
  --metadata data/metadata.csv \
  --output-dir data/splits \
  --mode temporal \
  --val-year 2024 \
  --test-year 2025
```

Audit the split before training:

```bash
python audit_dataset.py \
  --data-root data \
  --csv data/splits/train.csv data/splits/val.csv data/splits/test.csv \
  --check-images
```

## Training and evaluation

### 1. Train the segmentation model

```bash
python train_segmentation.py \
  --train-csv data/splits/train.csv \
  --val-csv data/splits/val.csv \
  --data-root data \
  --output-dir outputs/segmentation_full
```

### 2. Generate predicted masks

```bash
python evaluate_segmentation.py \
  --test-csv data/splits/val.csv \
  --checkpoint outputs/segmentation_full/best.pt \
  --data-root data \
  --output-dir outputs/segmentation_val

python evaluate_segmentation.py \
  --test-csv data/splits/test.csv \
  --checkpoint outputs/segmentation_full/best.pt \
  --data-root data \
  --output-dir outputs/segmentation_test
```

### 3. Train the multimodal classifier

The default workflow uses manual masks for classifier training and predicted
masks for validation and testing.

```bash
python train_classifier.py \
  --train-csv data/splits/train.csv \
  --val-csv outputs/segmentation_val/test_with_predicted_masks.csv \
  --data-root data \
  --train-mask-source manual \
  --val-mask-source predicted \
  --output-dir outputs/classifier_full
```

### 4. Independent test

```bash
python evaluate_classifier.py \
  --test-csv outputs/segmentation_test/test_with_predicted_masks.csv \
  --checkpoint outputs/classifier_full/best.pt \
  --data-root data \
  --mask-source predicted \
  --output-dir outputs/classifier_test \
  --bootstrap 2000
```

The main classification outputs are:

- `patient_predictions.csv`
- `metrics_with_95ci.json`
- `roc_curve.csv`
- `sample_predictions.csv`

Use patient-level results as the primary analysis when multiple images belong to
one patient.

## Ablation studies

Examples:

```bash
# Segmentation baseline: no PSA and no CARAFE
python train_segmentation.py ... --no-psa --no-carafe

# Disable PSA only
python train_segmentation.py ... --no-psa

# Disable CARAFE only
python train_segmentation.py ... --no-carafe

# Classification without CGA
python train_classifier.py ... --no-cga

# NBI-only model
python train_classifier.py ... --modality-mode nbi_only

# Manuscript WLI single-modality baseline: lesion-guided WLI only
# (raw WLI + explicit mask + mask-weighted WLI; no NBI)
python train_classifier.py ... --modality-mode wli_only --wli-input-mode full

# Optional diagnostic baseline: raw WLI only, without lesion guidance
python train_classifier.py ... --modality-mode wli_only --wli-input-mode raw

# Manuscript unguided multimodal baseline: raw WLI + NBI, no lesion-mask information
python train_classifier.py ... --modality-mode dual --wli-input-mode raw
```

A complete command-to-experiment map is provided in `docs/EXPERIMENTS.md`.

## Manuscript statistical analysis

The manuscript reports **Hanley-McNeil asymptotic 95% CIs for AUC** and **two-sided DeLong tests for paired ROC AUC comparisons**. After evaluating each frozen model on the same held-out patients, reproduce those analyses with:

```bash
python manuscript_statistics.py \
  --model "Lesion-guided WLI only=outputs/wli_only/patient_predictions.csv" \
  --model "NBI only=outputs/nbi_only/patient_predictions.csv" \
  --model "Unguided WLI+NBI=outputs/dual_raw/patient_predictions.csv" \
  --model "Predicted-mask model=outputs/final_predicted/patient_predictions.csv" \
  --model "Labeled-mask reference=outputs/final_manual/patient_predictions.csv" \
  --output-dir outputs/manuscript_statistics
```

`evaluate_classifier.py` can additionally report patient-level bootstrap intervals as a sensitivity analysis. Use `--ci-method hanley_mcneil`, `bootstrap`, or `both`.

## Reader study

Populate a private copy of `examples/reader_study_template.csv` using real,
independently collected reader decisions. The recommended schema includes the reader's five-point confidence score so the manuscript signed ordinal ROC score can be reproduced. Do not use synthetic reader results in a manuscript.

```bash
python analyze_reader_study.py \
  --reader-csv private/reader_study.csv \
  --ai-predictions outputs/classifier_test/patient_predictions.csv \
  --output-dir outputs/reader_study
```

## Pretrained weights

No pretrained weights are redistributed. See `models/pretrained/README.md`.
The code can run from random initialization.

## Reproducibility

- Positive class: EGC (`1`)
- Default random seed: `3047`
- Segmentation model selection: validation Dice
- Classification model selection: validation patient-level AUC
- Threshold selection: Youden index on the validation set only
- Manuscript AUC confidence intervals: Hanley-McNeil asymptotic method
- Pairwise AUC comparisons: two-sided DeLong test on the same held-out patients
- Optional sensitivity intervals from `evaluate_classifier.py`: patient-level bootstrap
- Test set: not used for model or threshold selection

The release was validated with the versions in `requirements-tested.txt`. See
`docs/REPRODUCIBILITY.md` for additional details.

## Privacy and data governance

Do not commit patient images, identifiers, pathology reports, real metadata,
reader decisions, or trained outputs derived from identifiable data. The
repository `.gitignore` excludes common data, image, checkpoint, and output
formats, but investigators remain responsible for de-identification and local
ethics requirements.

## Citation

See `CITATION.md` and cite the associated manuscript when available.

## License and third-party code

Original project code is released under the MIT License. RepVGG-derived code is
covered by the attribution and license notice in `THIRD_PARTY_NOTICES.md`.
