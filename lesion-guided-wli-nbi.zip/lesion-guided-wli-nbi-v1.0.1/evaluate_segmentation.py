"""Evaluate the frozen best segmentation model on the independent test set."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import DataLoader
from tqdm import tqdm

from data_pipeline import SegmentationDataset
from metrics import segmentation_metrics
from models import PSACARAFEResUNet
from reproducibility import json_safe, save_json, seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-csv", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--data-root", default=".")
    parser.add_argument("--output-dir", default="outputs/segmentation_test")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=3047)
    return parser.parse_args()


def bootstrap_patient_means(patient_frame: pd.DataFrame, metrics, n_bootstrap: int, seed: int):
    rng = np.random.default_rng(seed)
    output = {}
    n = len(patient_frame)
    for metric in metrics:
        samples = []
        for _ in range(n_bootstrap):
            indices = rng.integers(0, n, size=n)
            samples.append(float(patient_frame.iloc[indices][metric].mean()))
        output[metric] = {
            "estimate": float(patient_frame[metric].mean()),
            "lower_95": float(np.percentile(samples, 2.5)),
            "upper_95": float(np.percentile(samples, 97.5)),
        }
    return output


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    output_dir = Path(args.output_dir)
    mask_dir = output_dir / "predicted_masks"
    mask_dir.mkdir(parents=True, exist_ok=True)

    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model = PSACARAFEResUNet(
        use_psa=bool(checkpoint.get("use_psa", True)),
        use_carafe=bool(checkpoint.get("use_carafe", True)),
    )
    model.load_state_dict(checkpoint["model_state"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device).eval()

    image_size = tuple(checkpoint.get("image_size", [256, 256]))
    dataset = SegmentationDataset(args.test_csv, args.data_root, size=image_size, training=False)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.workers)
    rows = []
    with torch.no_grad():
        for batch in tqdm(loader):
            probabilities = torch.sigmoid(model(batch["image"].to(device))).cpu().numpy()
            targets = batch["mask"].numpy()
            for idx in range(len(batch["sample_id"])):
                prediction = probabilities[idx, 0] >= args.threshold
                target = targets[idx, 0] >= 0.5
                result = segmentation_metrics(target, prediction)
                sample_id = batch["sample_id"][idx]
                patient_id = batch["patient_id"][idx]
                mask_path = mask_dir / f"{sample_id}.png"
                Image.fromarray((prediction.astype(np.uint8) * 255)).save(mask_path)
                rows.append({"sample_id": sample_id, "patient_id": patient_id, "predicted_mask_path": str(mask_path.resolve()), **result})

    sample_frame = pd.DataFrame(rows)
    sample_frame.to_csv(output_dir / "sample_metrics.csv", index=False, encoding="utf-8-sig")
    metric_names = ["dice", "iou", "sensitivity", "specificity", "precision", "hd95"]
    patient_frame = sample_frame.groupby("patient_id", as_index=False)[metric_names].mean()
    patient_frame.to_csv(output_dir / "patient_metrics.csv", index=False, encoding="utf-8-sig")
    summary = bootstrap_patient_means(patient_frame, metric_names, args.bootstrap, args.seed)
    save_json(summary, output_dir / "metrics_with_95ci.json")

    metadata = pd.read_csv(args.test_csv, dtype={"sample_id": str, "patient_id": str})
    metadata = metadata.drop(columns=["predicted_mask_path"], errors="ignore").merge(
        sample_frame[["sample_id", "predicted_mask_path"]], on="sample_id", how="left"
    )
    metadata.to_csv(output_dir / "test_with_predicted_masks.csv", index=False, encoding="utf-8-sig")
    print(json.dumps(json_safe(summary), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
