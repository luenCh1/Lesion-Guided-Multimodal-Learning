# Experiment map

Replace `...` with the common dataset and output arguments shown in `README.md`.
Use a separate output directory for every experiment.

## Segmentation comparisons

| Experiment | Command flags |
|---|---|
| Residual U-Net baseline | `--no-psa --no-carafe` |
| PSA-ResUNet | `--no-carafe` |
| CARAFE-ResUNet | `--no-psa` |
| PSA-CARAFE-ResUNet | default |

Example:

```bash
python train_segmentation.py ... --no-psa --no-carafe --output-dir outputs/seg_baseline
python train_segmentation.py ... --no-carafe --output-dir outputs/seg_psa
python train_segmentation.py ... --no-psa --output-dir outputs/seg_carafe
python train_segmentation.py ... --output-dir outputs/seg_full
```

Evaluate every frozen checkpoint on the same independent test split.

## Classification modality and input ablations

The WLI branch has four input modes. **Important:** `--modality-mode wli_only`
with the default `--wli-input-mode full` is the manuscript's **lesion-guided
WLI-only** single-modality baseline; it is not raw WLI alone.

| Experiment | Command flags |
|---|---|
| NBI only | `--modality-mode nbi_only` |
| Lesion-guided WLI only (manuscript WLI single-modality baseline) | `--modality-mode wli_only --wli-input-mode full` |
| Raw WLI only (optional diagnostic baseline) | `--modality-mode wli_only --wli-input-mode raw` |
| Unguided WLI+NBI (manuscript multimodal baseline) | `--modality-mode dual --wli-input-mode raw` |
| WLI+NBI + explicit mask only | `--modality-mode dual --wli-input-mode raw_mask` |
| WLI+NBI + masked-WLI guidance only | `--modality-mode dual --wli-input-mode raw_masked` |
| Full lesion-guided WLI+NBI with CGA | `--modality-mode dual --wli-input-mode full` |
| Full lesion-guided WLI+NBI with conventional fusion | `--modality-mode dual --wli-input-mode full --no-cga` |
| Focal-loss sensitivity analysis | `--focal-loss` |

### Mask source for the manuscript configurations

- Training classifier: `--train-mask-source manual`.
- Final automated development/test configuration: predicted masks.
- Labeled-mask reference: manual consensus masks at development/test.
- The final automated model therefore uses **no manual mask at inference**.

Every training run now saves a human-readable `experiment_label` in
`config.json` and the checkpoint to reduce ambiguity when assembling tables.

## Computational efficiency

```bash
python benchmark_models.py --size 256
```

Install `thop` from `requirements-optional.txt` to include FLOPs. Report the
hardware, batch size, warm-up iterations, and repeat count with latency results.

## Reader study

Use the same independent patient test set for AI and every reader. The script
requires one row per reader-patient decision and compares paired correctness
using an exact McNemar test.
