# Public-release checklist

Before publishing a GitHub release:

- [ ] No patient images or clinical documents are present.
- [ ] No real metadata or reader-study CSV files are present.
- [ ] No model checkpoints trained on identifiable data are present.
- [ ] No local server paths, usernames, credentials, or API keys are present.
- [ ] `python smoke_test.py` passes.
- [ ] `pytest -q` passes.
- [ ] The repository version matches `VERSION` and `CITATION.md`.
- [ ] The manuscript cites the exact release tag or archive DOI.
- [ ] The institution has approved the selected software license.
