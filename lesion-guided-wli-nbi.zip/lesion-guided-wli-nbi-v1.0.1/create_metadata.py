"""Create a reviewable metadata CSV from the legacy data/our layout.

The generated patient_id is only an initial inference. You MUST review it and
fill the true examination year before patient-level or temporal splitting.
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", default="data/our")
    parser.add_argument("--label-file", default="label.txt")
    parser.add_argument("--output", default="metadata.csv")
    parser.add_argument(
        "--patient-regex",
        default=r"^([^()]+)",
        help="Regex applied to sample_id; first capture group becomes patient_id.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = Path(args.data_root)
    label_path = root / args.label_file
    rows = []
    pattern = re.compile(args.patient_regex)
    for line in label_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        sample_id, label = line.rsplit(maxsplit=1)
        match = pattern.search(sample_id)
        patient_id = match.group(1) if match else sample_id
        label = "EGC" if label.upper() in {"GC", "EGC"} else label.upper()
        rows.append(
            {
                "sample_id": sample_id,
                "patient_id": patient_id,
                "year": "",  # Must be filled with the true examination year from clinical records
                "label": label,
                "wli_path": f"images/{sample_id}.JPG",
                "nbi_path": f"images_nbi/{sample_id}.JPG",
                "manual_mask_path": f"masks/{sample_id}.png",
                "predicted_mask_path": f"masks_predict/{sample_id}.png",
            }
        )
    frame = pd.DataFrame(rows)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False, encoding="utf-8-sig")
    print(f"Created {output} with {len(frame)} samples and {frame.patient_id.nunique()} inferred patients.")
    print("Review patient_id and fill year before running split_dataset.py.")


if __name__ == "__main__":
    main()
