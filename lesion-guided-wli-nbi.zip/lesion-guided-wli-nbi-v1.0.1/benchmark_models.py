"""Report parameters and inference latency; FLOPs are optional via thop."""
from __future__ import annotations

import argparse
import json
import time

import torch

from models import LesionGuidedDualModel, PSACARAFEResUNet


def latency(model, inputs, device, warmup=10, repeats=50):
    model.eval()
    with torch.no_grad():
        for _ in range(warmup):
            model(*inputs) if isinstance(inputs, tuple) else model(inputs)
        if device.type == "cuda":
            torch.cuda.synchronize()
        start = time.perf_counter()
        for _ in range(repeats):
            model(*inputs) if isinstance(inputs, tuple) else model(inputs)
        if device.type == "cuda":
            torch.cuda.synchronize()
    return 1000.0 * (time.perf_counter() - start) / repeats


def maybe_flops(model, inputs):
    try:
        from thop import profile
    except ImportError:
        return None
    flops, _ = profile(model, inputs=inputs if isinstance(inputs, tuple) else (inputs,), verbose=False)
    return float(flops)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--size", type=int, default=256)
    args = parser.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    seg = PSACARAFEResUNet().to(device).eval()
    clf = LesionGuidedDualModel(pretrained=False).to(device).eval()
    x = torch.randn(1, 3, args.size, args.size, device=device)
    clf_inputs = (
        torch.rand(1, 3, args.size, args.size, device=device),
        torch.rand(1, 3, args.size, args.size, device=device),
        torch.rand(1, 1, args.size, args.size, device=device),
    )
    report = {
        "device": str(device),
        "segmentation": {
            "parameters": sum(p.numel() for p in seg.parameters()),
            "latency_ms": latency(seg, x, device),
            "flops": maybe_flops(seg, x),
        },
        "classification": {
            "parameters": sum(p.numel() for p in clf.parameters()),
            "latency_ms": latency(clf, clf_inputs, device),
            "flops": maybe_flops(clf, clf_inputs),
        },
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
