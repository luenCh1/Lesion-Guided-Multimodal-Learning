# Example files

The CSV files in this directory contain **synthetic placeholders only**. They do
not contain clinical data and must not be used as study results.

- `metadata_template.csv`: required columns for paired WLI-NBI samples.
- `reader_study_template.csv`: long-format reader-study input.

Copy a template outside the repository and replace every example row with your
own de-identified records. Do not commit clinical data, identifiers, images, or
model outputs derived from identifiable patients.
