"""Patient-level metrics, confidence intervals, and segmentation measures."""
from __future__ import annotations

from typing import Callable, Dict, Iterable

import numpy as np
import pandas as pd
from scipy.ndimage import binary_erosion, distance_transform_edt
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)


def binary_classification_metrics(y_true: np.ndarray, y_score: np.ndarray, threshold: float = 0.5) -> Dict[str, float]:
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    y_pred = (y_score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "auc": float(roc_auc_score(y_true, y_score)) if len(np.unique(y_true)) == 2 else float("nan"),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "sensitivity": float(tp / (tp + fn)) if tp + fn else float("nan"),
        "specificity": float(tn / (tn + fp)) if tn + fp else float("nan"),
        "precision": float(tp / (tp + fp)) if tp + fp else float("nan"),
        "npv": float(tn / (tn + fn)) if tn + fn else float("nan"),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "threshold": float(threshold),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def youden_threshold(y_true: np.ndarray, y_score: np.ndarray) -> float:
    fpr, tpr, thresholds = roc_curve(y_true, y_score)
    finite = np.isfinite(thresholds)
    if not finite.any():
        return 0.5
    index = np.argmax((tpr - fpr)[finite])
    return float(thresholds[finite][index])


def aggregate_patient_predictions(frame: pd.DataFrame, method: str = "mean") -> pd.DataFrame:
    if method not in {"mean", "max"}:
        raise ValueError("Patient aggregation method must be mean or max")
    label_counts = frame.groupby("patient_id")["label"].nunique()
    if (label_counts > 1).any():
        raise ValueError("A patient has inconsistent labels")
    agg_func = "mean" if method == "mean" else "max"
    return (
        frame.groupby("patient_id", as_index=False)
        .agg(label=("label", "first"), egc_probability=("egc_probability", agg_func), n_images=("sample_id", "count"))
    )


def bootstrap_metric_intervals(
    frame: pd.DataFrame,
    threshold: float,
    n_bootstrap: int = 2000,
    seed: int = 3047,
) -> Dict[str, Dict[str, float]]:
    """Patient-level bootstrap confidence intervals.

    The input must contain one row per patient with label and egc_probability.
    """
    rng = np.random.default_rng(seed)
    values = {key: [] for key in ["auc", "accuracy", "sensitivity", "specificity", "precision", "npv", "f1"]}
    n = len(frame)
    for _ in range(n_bootstrap):
        indices = rng.integers(0, n, size=n)
        sample = frame.iloc[indices]
        if sample.label.nunique() < 2:
            continue
        metrics = binary_classification_metrics(sample.label.to_numpy(), sample.egc_probability.to_numpy(), threshold)
        for key in values:
            if np.isfinite(metrics[key]):
                values[key].append(metrics[key])
    output = {}
    for key, samples in values.items():
        if samples:
            output[key] = {
                "lower_95": float(np.percentile(samples, 2.5)),
                "upper_95": float(np.percentile(samples, 97.5)),
            }
        else:
            output[key] = {"lower_95": float("nan"), "upper_95": float("nan")}
    return output


def segmentation_metrics(target: np.ndarray, prediction: np.ndarray) -> Dict[str, float]:
    target = np.asarray(target, dtype=bool)
    prediction = np.asarray(prediction, dtype=bool)
    tp = np.logical_and(target, prediction).sum()
    tn = np.logical_and(~target, ~prediction).sum()
    fp = np.logical_and(~target, prediction).sum()
    fn = np.logical_and(target, ~prediction).sum()
    eps = 1e-8
    dice = (2 * tp + eps) / (2 * tp + fp + fn + eps)
    iou = (tp + eps) / (tp + fp + fn + eps)
    sensitivity = (tp + eps) / (tp + fn + eps)
    specificity = (tn + eps) / (tn + fp + eps)
    precision = (tp + eps) / (tp + fp + eps)
    return {
        "dice": float(dice),
        "iou": float(iou),
        "sensitivity": float(sensitivity),
        "specificity": float(specificity),
        "precision": float(precision),
        "hd95": float(hd95(target, prediction)),
    }


def hd95(target: np.ndarray, prediction: np.ndarray) -> float:
    if not target.any() and not prediction.any():
        return 0.0
    if not target.any() or not prediction.any():
        return float("nan")
    target_surface = np.logical_xor(target, binary_erosion(target))
    pred_surface = np.logical_xor(prediction, binary_erosion(prediction))
    target_distance = distance_transform_edt(~target_surface)
    pred_distance = distance_transform_edt(~pred_surface)
    distances = np.concatenate([target_distance[pred_surface], pred_distance[target_surface]])
    return float(np.percentile(distances, 95)) if distances.size else 0.0
