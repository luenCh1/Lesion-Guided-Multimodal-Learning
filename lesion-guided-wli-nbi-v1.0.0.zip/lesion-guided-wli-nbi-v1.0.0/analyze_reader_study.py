"""Analyze the 11-endoscopist reader study against the AI model.

Reader CSV (long format):
patient_id,label,reader_id,reader_level,prediction,reading_time_seconds

Labels/predictions may be GPL/EGC or 0/1. AI predictions are produced by
evaluate_classifier.py (patient_predictions.csv).
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest

from metrics import binary_classification_metrics


def parse_label(value):
    text = str(value).strip().upper()
    if text in {"EGC", "GC", "1", "1.0"}:
        return 1
    if text in {"GPL", "0", "0.0"}:
        return 0
    raise ValueError(f"Unknown label: {value}")


def mcnemar_exact(ai_correct: np.ndarray, reader_correct: np.ndarray):
    ai_only = int(np.sum(ai_correct & ~reader_correct))
    reader_only = int(np.sum(~ai_correct & reader_correct))
    discordant = ai_only + reader_only
    p_value = 1.0 if discordant == 0 else float(binomtest(min(ai_only, reader_only), discordant, 0.5, alternative="two-sided").pvalue)
    return ai_only, reader_only, p_value


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reader-csv", required=True)
    parser.add_argument("--ai-predictions", required=True)
    parser.add_argument("--output-dir", default="outputs/reader_study")
    return parser.parse_args()


def main():
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    readers = pd.read_csv(args.reader_csv, dtype={"patient_id": str, "reader_id": str})
    required = {"patient_id", "label", "reader_id", "reader_level", "prediction", "reading_time_seconds"}
    missing = required.difference(readers.columns)
    if missing:
        raise ValueError(f"Reader CSV missing columns: {sorted(missing)}")
    readers["label"] = readers["label"].map(parse_label)
    readers["prediction"] = readers["prediction"].map(parse_label)

    ai = pd.read_csv(args.ai_predictions, dtype={"patient_id": str})
    if "predicted_label" not in ai.columns:
        raise ValueError("AI predictions must contain predicted_label")
    if "label" not in ai.columns:
        raise ValueError("AI predictions must contain label")
    ai["label"] = ai["label"].map(parse_label)
    ai["predicted_label"] = ai["predicted_label"].map(parse_label)

    rows = []
    for reader_id, group in readers.groupby("reader_id"):
        merged = group.merge(ai[["patient_id", "label", "predicted_label", "egc_probability"]], on="patient_id", suffixes=("_reader", "_ai"))
        if len(merged) != len(ai):
            raise ValueError(f"Reader {reader_id} did not assess all AI test patients: {len(merged)} vs {len(ai)}")
        if not np.array_equal(merged.label_reader.to_numpy(), merged.label_ai.to_numpy()):
            raise ValueError(f"Label mismatch for reader {reader_id}")
        labels = merged.label_reader.to_numpy()
        reader_scores = merged.prediction.to_numpy().astype(float)
        reader_metrics = binary_classification_metrics(labels, reader_scores, threshold=0.5)
        ai_correct = merged.predicted_label.to_numpy() == labels
        reader_correct = merged.prediction.to_numpy() == labels
        ai_only, reader_only, p_value = mcnemar_exact(ai_correct, reader_correct)
        rows.append(
            {
                "reader_id": reader_id,
                "reader_level": str(group.reader_level.iloc[0]),
                **{f"reader_{key}": value for key, value in reader_metrics.items() if key not in {"threshold", "tn", "fp", "fn", "tp"}},
                "mean_reading_time_seconds": float(group.reading_time_seconds.mean()),
                "median_reading_time_seconds": float(group.reading_time_seconds.median()),
                "ai_correct_reader_wrong": ai_only,
                "ai_wrong_reader_correct": reader_only,
                "mcnemar_exact_p": p_value,
            }
        )
    reader_results = pd.DataFrame(rows)
    reader_results.to_csv(output_dir / "reader_level_results.csv", index=False, encoding="utf-8-sig")

    numeric = [column for column in reader_results.columns if column.startswith("reader_") and column not in {"reader_id", "reader_level"}]
    level_summary = reader_results.groupby("reader_level", as_index=False)[numeric + ["mean_reading_time_seconds", "median_reading_time_seconds"]].mean()
    level_summary.to_csv(output_dir / "experience_level_summary.csv", index=False, encoding="utf-8-sig")

    ai_threshold = float(ai["threshold"].iloc[0]) if "threshold" in ai.columns else 0.5
    ai_metrics = binary_classification_metrics(ai.label.to_numpy(), ai.egc_probability.to_numpy(), threshold=ai_threshold)
    pd.DataFrame([ai_metrics]).to_csv(output_dir / "ai_metrics.csv", index=False)
    print(reader_results.to_string(index=False))


if __name__ == "__main__":
    main()
