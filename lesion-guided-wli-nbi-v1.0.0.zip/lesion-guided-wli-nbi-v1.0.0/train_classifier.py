"""Train the lesion-guided WLI-NBI classifier using train and validation patients."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

from data_pipeline import MultimodalDataset, load_metadata
from losses import MulticlassFocalLoss
from metrics import aggregate_patient_predictions, binary_classification_metrics, youden_threshold
from models import LesionGuidedDualModel
from reproducibility import save_json, seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-csv", required=True)
    parser.add_argument("--val-csv", required=True)
    parser.add_argument("--data-root", default=".")
    parser.add_argument("--output-dir", default="outputs/classifier")
    parser.add_argument("--train-mask-source", choices=["manual", "predicted"], default="manual")
    parser.add_argument("--val-mask-source", choices=["manual", "predicted"], default="predicted")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--image-size", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=3047)
    parser.add_argument("--pretrained", action="store_true")
    parser.add_argument("--no-cga", action="store_true")
    parser.add_argument("--modality-mode", choices=["dual", "nbi_only", "wli_only"], default="dual")
    parser.add_argument("--wli-input-mode", choices=["full", "raw", "raw_mask", "raw_masked"], default="full")
    parser.add_argument("--focal-loss", action="store_true")
    parser.add_argument("--patient-aggregation", choices=["mean", "max"], default="mean")
    return parser.parse_args()


def class_weights(csv_path: str, device: torch.device) -> torch.Tensor:
    frame = load_metadata(csv_path).drop_duplicates("patient_id")
    counts = frame["label"].value_counts()
    weights = np.array([1.0 / counts.get("GPL", 1), 1.0 / counts.get("EGC", 1)], dtype=np.float32)
    weights = weights / weights.mean()
    return torch.tensor(weights, device=device)


def run_epoch(model, loader, criterion, device, optimizer=None):
    training = optimizer is not None
    model.train(training)
    total_loss = 0.0
    rows = []
    progress = tqdm(loader, leave=False)
    for batch in progress:
        nbi = batch["nbi"].to(device, non_blocking=True)
        wli = batch["wli"].to(device, non_blocking=True)
        mask = batch["mask"].to(device, non_blocking=True)
        labels = batch["label"].to(device, non_blocking=True)
        if training:
            optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(training):
            logits = model(nbi, wli, mask)
            loss = criterion(logits, labels)
            if training:
                loss.backward()
                optimizer.step()
        probabilities = torch.softmax(logits.detach(), dim=1)[:, 1].cpu().numpy()
        for i in range(len(batch["sample_id"])):
            rows.append(
                {
                    "sample_id": batch["sample_id"][i],
                    "patient_id": batch["patient_id"][i],
                    "label": int(labels[i].item()),
                    "egc_probability": float(probabilities[i]),
                }
            )
        total_loss += float(loss.item()) * labels.size(0)
        progress.set_postfix(loss=f"{total_loss / len(rows):.4f}")
    return total_loss / len(rows), pd.DataFrame(rows)


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    save_json(vars(args), output_dir / "config.json")

    image_size = (args.image_size, args.image_size)
    train_set = MultimodalDataset(args.train_csv, args.data_root, size=image_size, training=True, mask_source=args.train_mask_source)
    val_set = MultimodalDataset(args.val_csv, args.data_root, size=image_size, training=False, mask_source=args.val_mask_source)
    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.workers, pin_memory=True, drop_last=False)
    val_loader = DataLoader(val_set, batch_size=args.batch_size, shuffle=False, num_workers=args.workers, pin_memory=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = LesionGuidedDualModel(
        use_cga=not args.no_cga,
        pretrained=args.pretrained,
        modality_mode=args.modality_mode,
        wli_input_mode=args.wli_input_mode,
    ).to(device)
    weights = class_weights(args.train_csv, device)
    criterion = MulticlassFocalLoss(class_weights=weights) if args.focal_loss else torch.nn.CrossEntropyLoss(weight=weights)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)

    history_path = output_dir / "history.csv"
    fields = ["epoch", "learning_rate", "train_loss", "train_patient_auc", "val_loss", "val_patient_auc", "val_threshold", "val_accuracy", "val_sensitivity", "val_specificity"]
    with history_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()

    best_auc = -1.0
    for epoch in range(1, args.epochs + 1):
        train_loss, train_samples = run_epoch(model, train_loader, criterion, device, optimizer)
        with torch.no_grad():
            val_loss, val_samples = run_epoch(model, val_loader, criterion, device)
        train_patients = aggregate_patient_predictions(train_samples, args.patient_aggregation)
        val_patients = aggregate_patient_predictions(val_samples, args.patient_aggregation)
        train_auc = binary_classification_metrics(train_patients.label, train_patients.egc_probability)["auc"]
        threshold = youden_threshold(val_patients.label.to_numpy(), val_patients.egc_probability.to_numpy())
        val_metrics = binary_classification_metrics(val_patients.label, val_patients.egc_probability, threshold)
        scheduler.step()

        row = {
            "epoch": epoch,
            "learning_rate": optimizer.param_groups[0]["lr"],
            "train_loss": train_loss,
            "train_patient_auc": train_auc,
            "val_loss": val_loss,
            "val_patient_auc": val_metrics["auc"],
            "val_threshold": threshold,
            "val_accuracy": val_metrics["accuracy"],
            "val_sensitivity": val_metrics["sensitivity"],
            "val_specificity": val_metrics["specificity"],
        }
        with history_path.open("a", newline="", encoding="utf-8") as handle:
            csv.DictWriter(handle, fieldnames=fields).writerow(row)
        checkpoint = {
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "epoch": epoch,
            "val_auc": val_metrics["auc"],
            "threshold": threshold,
            "use_cga": not args.no_cga,
            "patient_aggregation": args.patient_aggregation,
            "modality_mode": args.modality_mode,
            "wli_input_mode": args.wli_input_mode,
            "positive_class": "EGC",
            "image_size": [args.image_size, args.image_size],
            "label_mapping": {"GPL": 0, "EGC": 1},
        }
        torch.save(checkpoint, output_dir / "last.pt")
        if val_metrics["auc"] > best_auc:
            best_auc = val_metrics["auc"]
            torch.save(checkpoint, output_dir / "best.pt")
            val_samples.to_csv(output_dir / "best_val_sample_predictions.csv", index=False)
            val_patients.to_csv(output_dir / "best_val_patient_predictions.csv", index=False)
        print(
            f"Epoch {epoch:03d}: train_loss={train_loss:.4f}, val_loss={val_loss:.4f}, "
            f"val_patient_auc={val_metrics['auc']:.4f}, threshold={threshold:.4f}, best={best_auc:.4f}"
        )


if __name__ == "__main__":
    main()
