import numpy as np
import pandas as pd

from metrics import aggregate_patient_predictions, binary_classification_metrics, segmentation_metrics


def test_perfect_binary_metrics():
    metrics = binary_classification_metrics(np.array([0, 1]), np.array([0.1, 0.9]), threshold=0.5)
    assert metrics["auc"] == 1.0
    assert metrics["accuracy"] == 1.0
    assert metrics["sensitivity"] == 1.0
    assert metrics["specificity"] == 1.0


def test_patient_aggregation_mean():
    frame = pd.DataFrame(
        {
            "sample_id": ["a", "b", "c"],
            "patient_id": ["p1", "p1", "p2"],
            "label": [1, 1, 0],
            "egc_probability": [0.8, 0.6, 0.2],
        }
    )
    result = aggregate_patient_predictions(frame, "mean").set_index("patient_id")
    assert np.isclose(result.loc["p1", "egc_probability"], 0.7)
    assert result.loc["p1", "n_images"] == 2


def test_perfect_segmentation_metrics():
    mask = np.zeros((16, 16), dtype=bool)
    mask[4:12, 4:12] = True
    metrics = segmentation_metrics(mask, mask)
    assert np.isclose(metrics["dice"], 1.0)
    assert np.isclose(metrics["iou"], 1.0)
    assert np.isclose(metrics["hd95"], 0.0)
