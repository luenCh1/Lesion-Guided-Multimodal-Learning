"""Independent patient-level evaluation of the frozen classification model."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch
from sklearn.metrics import roc_curve
from torch.utils.data import DataLoader
from tqdm import tqdm

from data_pipeline import MultimodalDataset
from metrics import aggregate_patient_predictions, binary_classification_metrics, bootstrap_metric_intervals
from models import LesionGuidedDualModel
from reproducibility import json_safe, save_json, seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-csv", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--data-root", default=".")
    parser.add_argument("--output-dir", default="outputs/classifier_test")
    parser.add_argument("--mask-source", choices=["manual", "predicted"], default="predicted")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=3047)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model = LesionGuidedDualModel(
        use_cga=bool(checkpoint.get("use_cga", True)),
        pretrained=False,
        modality_mode=checkpoint.get("modality_mode", "dual"),
        wli_input_mode=checkpoint.get("wli_input_mode", "full"),
    )
    model.load_state_dict(checkpoint["model_state"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device).eval()

    image_size = tuple(checkpoint.get("image_size", [256, 256]))
    dataset = MultimodalDataset(args.test_csv, args.data_root, size=image_size, training=False, mask_source=args.mask_source)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.workers)
    rows = []
    with torch.no_grad():
        for batch in tqdm(loader):
            logits = model(batch["nbi"].to(device), batch["wli"].to(device), batch["mask"].to(device))
            probabilities = torch.softmax(logits, dim=1)[:, 1].cpu().numpy()
            for i in range(len(batch["sample_id"])):
                rows.append(
                    {
                        "sample_id": batch["sample_id"][i],
                        "patient_id": batch["patient_id"][i],
                        "label": int(batch["label"][i].item()),
                        "egc_probability": float(probabilities[i]),
                    }
                )
    sample_frame = pd.DataFrame(rows)
    aggregation = checkpoint.get("patient_aggregation", "mean")
    patient_frame = aggregate_patient_predictions(sample_frame, aggregation)
    threshold = float(checkpoint.get("threshold", 0.5))
    metrics = binary_classification_metrics(patient_frame.label, patient_frame.egc_probability, threshold)
    intervals = bootstrap_metric_intervals(patient_frame, threshold, args.bootstrap, args.seed)
    report = {"patient_level": metrics, "confidence_intervals": intervals, "aggregation": aggregation, "positive_class": "EGC"}

    sample_frame.to_csv(output_dir / "sample_predictions.csv", index=False, encoding="utf-8-sig")
    patient_frame.assign(predicted_label=(patient_frame.egc_probability >= threshold).astype(int), threshold=threshold).to_csv(
        output_dir / "patient_predictions.csv", index=False, encoding="utf-8-sig"
    )
    fpr, tpr, thresholds = roc_curve(patient_frame.label, patient_frame.egc_probability)
    pd.DataFrame({"fpr": fpr, "tpr": tpr, "threshold": thresholds}).to_csv(output_dir / "roc_curve.csv", index=False)
    save_json(report, output_dir / "metrics_with_95ci.json")
    print(json.dumps(json_safe(report), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
