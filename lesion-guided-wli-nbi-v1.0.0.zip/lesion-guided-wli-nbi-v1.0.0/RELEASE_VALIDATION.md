# Release validation

Release: **1.0.0**  
Validation date: **2026-07-19**

The public code package was checked without clinical data:

- all Python files compiled successfully;
- `python smoke_test.py` passed;
- `pytest -q` passed: 6 tests;
- segmentation output shape was verified;
- classification output shape was verified;
- binary classification and segmentation metric tests passed;
- patient-level random splitting was verified to produce disjoint patient sets;
- no patient images, model checkpoints, real clinical metadata, or reader-study
  results are included.

These checks validate software execution only. They do not reproduce or certify
any manuscript result, which must be generated from the investigators' private,
ethics-approved dataset.
