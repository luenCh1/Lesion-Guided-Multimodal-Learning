# Experiment map

Replace `...` with the common dataset and output arguments shown in `README.md`.
Use a separate output directory for every experiment.

## Segmentation comparisons

| Experiment | Command flags |
|---|---|
| Residual U-Net baseline | `--no-psa --no-carafe` |
| PSA-ResUNet | `--no-carafe` |
| CARAFE-ResUNet | `--no-psa` |
| PSA-CARAFE-ResUNet | default |

Example:

```bash
python train_segmentation.py ... --no-psa --no-carafe --output-dir outputs/seg_baseline
python train_segmentation.py ... --no-carafe --output-dir outputs/seg_psa
python train_segmentation.py ... --no-psa --output-dir outputs/seg_carafe
python train_segmentation.py ... --output-dir outputs/seg_full
```

Evaluate every frozen checkpoint on the same independent test split.

## Classification modality and input ablations

| Experiment | Command flags |
|---|---|
| NBI only | `--modality-mode nbi_only` |
| Lesion-guided WLI only | `--modality-mode wli_only` |
| Dual modality without CGA | `--no-cga` |
| WLI without mask information | `--wli-input-mode raw` |
| WLI + explicit mask | `--wli-input-mode raw_mask` |
| WLI + masked WLI | `--wli-input-mode raw_masked` |
| Full WLI + mask + masked WLI and NBI | default |
| Focal-loss sensitivity analysis | `--focal-loss` |

## Computational efficiency

```bash
python benchmark_models.py --size 256
```

Install `thop` from `requirements-optional.txt` to include FLOPs. Report the
hardware, batch size, warm-up iterations, and repeat count with latency results.

## Reader study

Use the same independent patient test set for AI and every reader. The script
requires one row per reader-patient decision and compares paired correctness
using an exact McNemar test.
