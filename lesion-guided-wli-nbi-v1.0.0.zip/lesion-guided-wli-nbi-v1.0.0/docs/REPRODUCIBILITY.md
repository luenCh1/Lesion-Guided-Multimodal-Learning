# Reproducibility notes

## Determinism

`seed_everything()` seeds Python, NumPy, and PyTorch, disables cuDNN benchmarking,
and requests deterministic algorithms where supported. Exact bitwise
reproducibility can still depend on operating system, hardware, CUDA, and
library versions.

## Model selection

- Segmentation: the checkpoint with the highest validation Dice is saved as
  `best.pt`.
- Classification: the checkpoint with the highest validation patient-level AUC
  is saved as `best.pt`.
- Classification threshold: estimated on the validation set using the Youden
  index and stored in the checkpoint.
- Independent test: the saved model and threshold are frozen before test-set
  evaluation.

## Statistical unit

When multiple image pairs belong to the same patient, sample probabilities are
aggregated at patient level (`mean` by default). Confidence intervals are
computed by resampling patients, not images.

## Suggested reporting

Record and report:

- exact patient and sample counts in every split;
- class distribution by patient and sample;
- split method and random seed;
- software versions and hardware;
- all training hyperparameters;
- patient aggregation method;
- threshold-selection method;
- number of bootstrap repetitions;
- whether manual or predicted masks were used at every stage;
- whether pretrained weights were used and their source.

## Release validation

Run:

```bash
python -m compileall .
python smoke_test.py
pytest -q
```

The release package contains no study results. All manuscript numbers must be
recomputed from the investigator's private, ethics-approved dataset.
