#!/usr/bin/env python3
"""Analyze the six-reader study used in the manuscript.

Expected columns:
patient_id,label,reader_id,reader_level,prediction,confidence,reading_time_seconds

label/prediction: 0=GPL, 1=EGC
confidence: integer 1-5
Reader AUC is calculated from a signed ordinal score:
GPL diagnosis -> -confidence; EGC diagnosis -> +confidence.
"""
import argparse
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, roc_auc_score
from scipy.stats import binomtest


def exact_mcnemar(y_true, a, b):
    ca = np.asarray(a) == np.asarray(y_true)
    cb = np.asarray(b) == np.asarray(y_true)
    n01 = int((~ca & cb).sum())
    n10 = int((ca & ~cb).sum())
    n = n01 + n10
    p = 1.0 if n == 0 else float(binomtest(min(n01, n10), n=n, p=0.5, alternative="two-sided").pvalue)
    return n01, n10, p


def binary_metrics(y, pred):
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0,1]).ravel()
    return {
        "accuracy": (tp+tn)/(tp+tn+fp+fn),
        "sensitivity": tp/(tp+fn) if tp+fn else np.nan,
        "specificity": tn/(tn+fp) if tn+fp else np.nan,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("reader_csv")
    ap.add_argument("--model-csv", help="Optional patient_predictions.csv with patient_id,label,prediction")
    args = ap.parse_args()
    df = pd.read_csv(args.reader_csv)
    required = {"patient_id","label","reader_id","reader_level","prediction","confidence"}
    missing = required.difference(df.columns)
    if missing:
        raise SystemExit(f"Missing columns: {sorted(missing)}")
    if not df["confidence"].between(1,5).all():
        raise SystemExit("confidence must be 1-5")

    rows=[]
    for rid, g in df.groupby("reader_id"):
        y=g["label"].astype(int).to_numpy()
        pred=g["prediction"].astype(int).to_numpy()
        conf=g["confidence"].astype(float).to_numpy()
        score=np.where(pred==1, conf, -conf)
        m=binary_metrics(y,pred)
        m.update({
            "reader_id":rid,
            "reader_level":g["reader_level"].iloc[0],
            "auc_confidence_score":roc_auc_score(y,score),
            "n":len(g),
        })
        rows.append(m)
    out=pd.DataFrame(rows)
    print(out.to_string(index=False))

    if args.model_csv:
        model=pd.read_csv(args.model_csv)
        if "prediction" not in model.columns:
            raise SystemExit("model CSV must include prediction for McNemar analysis")
        for rid,g in df.groupby("reader_id"):
            m=g[["patient_id","label","prediction"]].merge(
                model[["patient_id","label","prediction"]], on=["patient_id","label"],
                suffixes=("_reader","_model")
            )
            n01,n10,p=exact_mcnemar(m["label"],m["prediction_reader"],m["prediction_model"])
            print(f"{rid} vs model: reader-wrong/model-right={n01}, reader-right/model-wrong={n10}, exact McNemar P={p:.6g}")


if __name__ == "__main__":
    main()
