# Release validation — v1.0.1-final

This release is aligned with the BMC Medical Imaging submission manuscript.

Key manuscript-aligned items:
- AdamW training configuration.
- Development-set AUC checkpoint selection.
- Development-set Youden-index threshold selection.
- Explicit lesion-guided WLI-only naming.
- Hanley–McNeil AUC confidence intervals.
- Paired DeLong AUC comparison utility.
- Confidence-aware reader AUC analysis.
- Patient-level data-leakage safeguards.
- Clinical dataset is intentionally not distributed because of ethics/privacy/data-governance restrictions.

The release contains implementation code only; it does not claim that third parties can reproduce the manuscript's numerical results without access to an appropriately governed clinical dataset.
