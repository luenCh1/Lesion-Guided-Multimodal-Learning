# Citation

Associated manuscript:

**Registration-Free Lesion-Guided Fusion of White-Light and Narrow-Band Endoscopy for Differentiating Gastric Precancerous Lesions from Early Gastric Cancer: A Retrospective Diagnostic Imaging Study**

Until a journal citation is available, cite the repository:

Cai H. Lesion-Guided-Multimodal-Learning. GitHub.  
https://github.com/luenCh1/Lesion-Guided-Multimodal-Learning
