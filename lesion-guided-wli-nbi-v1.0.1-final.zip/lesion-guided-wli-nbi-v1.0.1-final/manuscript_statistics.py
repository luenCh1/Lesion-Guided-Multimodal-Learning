#!/usr/bin/env python3
"""Statistics used in the associated BMC Medical Imaging manuscript.

Provides:
- Hanley–McNeil asymptotic 95% CI for ROC AUC.
- Paired DeLong test for correlated ROC AUCs.
- A CLI for patient-level prediction CSV files.

Expected CSV columns:
    patient_id,label,probability
where label is 0 (GPL) or 1 (EGC).
"""

from __future__ import annotations
import argparse
import math
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.metrics import roc_auc_score


def hanley_mcneil_auc_ci(y_true, y_score, alpha=0.05):
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    auc = float(roc_auc_score(y_true, y_score))
    n1 = int((y_true == 1).sum())
    n0 = int((y_true == 0).sum())
    if n1 == 0 or n0 == 0:
        raise ValueError("Both classes are required.")
    q1 = auc / (2.0 - auc)
    q2 = 2.0 * auc * auc / (1.0 + auc)
    se = math.sqrt(
        (auc * (1.0 - auc)
         + (n1 - 1) * (q1 - auc * auc)
         + (n0 - 1) * (q2 - auc * auc))
        / (n0 * n1)
    )
    z = float(norm.ppf(1.0 - alpha / 2.0))
    return auc, max(0.0, auc - z * se), min(1.0, auc + z * se)


def _compute_midrank(x):
    order = np.argsort(x)
    z = x[order]
    n = len(x)
    t = np.zeros(n, dtype=float)
    i = 0
    while i < n:
        j = i
        while j < n and z[j] == z[i]:
            j += 1
        t[i:j] = 0.5 * (i + j - 1) + 1.0
        i = j
    out = np.empty(n, dtype=float)
    out[order] = t
    return out


def _fast_delong(predictions_sorted_transposed, label_1_count):
    m = label_1_count
    n = predictions_sorted_transposed.shape[1] - m
    pos = predictions_sorted_transposed[:, :m]
    neg = predictions_sorted_transposed[:, m:]
    k = predictions_sorted_transposed.shape[0]
    tx = np.empty((k, m))
    ty = np.empty((k, n))
    tz = np.empty((k, m + n))
    for r in range(k):
        tx[r] = _compute_midrank(pos[r])
        ty[r] = _compute_midrank(neg[r])
        tz[r] = _compute_midrank(predictions_sorted_transposed[r])
    aucs = tz[:, :m].sum(axis=1) / m / n - (m + 1.0) / (2.0 * n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    sx = np.cov(v01)
    sy = np.cov(v10)
    cov = sx / m + sy / n
    return aucs, np.atleast_2d(cov)


def delong_test(y_true, score_a, score_b):
    y_true = np.asarray(y_true, dtype=int)
    score_a = np.asarray(score_a, dtype=float)
    score_b = np.asarray(score_b, dtype=float)
    if not (len(y_true) == len(score_a) == len(score_b)):
        raise ValueError("Inputs must have equal length.")
    order = np.argsort(-y_true)
    m = int(y_true.sum())
    preds = np.vstack([score_a, score_b])[:, order]
    aucs, cov = _fast_delong(preds, m)
    contrast = np.array([1.0, -1.0])
    var = float(contrast @ cov @ contrast.T)
    if var <= 0:
        p = 1.0 if np.isclose(aucs[0], aucs[1]) else 0.0
    else:
        z = abs(float(aucs[0] - aucs[1])) / math.sqrt(var)
        p = float(2.0 * norm.sf(z))
    return float(aucs[0]), float(aucs[1]), p


def load_predictions(path):
    df = pd.read_csv(path)
    required = {"patient_id", "label", "probability"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"{path}: missing columns {sorted(missing)}")
    return df[["patient_id", "label", "probability"]].copy()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+", help="patient_predictions.csv files")
    ap.add_argument("--names", nargs="*", help="Optional model names, same order as files")
    args = ap.parse_args()

    names = args.names or [PathLike.split("/")[-2] if "/" in PathLike else PathLike for PathLike in args.files]
    if len(names) != len(args.files):
        raise SystemExit("--names must match number of files")

    dfs = [load_predictions(p) for p in args.files]
    base = dfs[0][["patient_id", "label"]].rename(columns={"label": "label_ref"})
    merged = base.copy()
    for name, df in zip(names, dfs):
        tmp = df.rename(columns={"label": f"label_{name}", "probability": name})
        merged = merged.merge(tmp, on="patient_id", how="inner")
        if not np.array_equal(merged["label_ref"].to_numpy(), merged[f"label_{name}"].to_numpy()):
            raise ValueError(f"Label mismatch for model {name}")

    y = merged["label_ref"].to_numpy()
    print("Hanley–McNeil AUC 95% CI")
    for name in names:
        auc, lo, hi = hanley_mcneil_auc_ci(y, merged[name].to_numpy())
        print(f"{name}: AUC={auc:.4f}, 95% CI={lo:.4f}-{hi:.4f}")

    if len(names) > 1:
        print("\nPaired DeLong tests")
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                a1, a2, p = delong_test(y, merged[names[i]].to_numpy(), merged[names[j]].to_numpy())
                print(f"{names[i]} vs {names[j]}: ΔAUC={a1-a2:+.4f}, P={p:.6g}")


if __name__ == "__main__":
    main()
